MEDICAL SOFTWARE 2006
M-TEchnology Indonesia

How to use this code :
- Extract this file to C:\VBDOCTOR directory
- Copy "vb6.exe.manifest" to visualbasic directory

Best Regards
Manik Artawan