Hi. I created this project for one of supermarket in my town. No i have a lot of projects and i decided to share this project
with you. I appologies for my English. I got not enough time to translate all codes in English because i created this software in
my language. so sorry about that. I translated only the interface and some codes in project.
Thi software is designed for retail stores. I'ts not 100% finished. I share this just for learning database programming. So, if u see something
is not finished, try to finish because i got not enough time to finish because i am working hard in my other projects.
For the end i want to thank Allah for giving me knowledge and all of you. I learned to much from PSC and i decided to share this code with you.
I hope you like this project !

Database password:  cc03bn01


Default username:
Username:  admin
Password:   admin


You can vote for this project if u like it, but if u don't like it, i'ts ok, don't vote.

Bye.