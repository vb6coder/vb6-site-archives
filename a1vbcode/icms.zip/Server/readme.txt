client password

emergency password

user: admin
password: jaypee

for more information:
jayipee@yahoo.com