---------------------------------------------------------------------------------------------------------------------------
create database lms
---------------------------------------------------------------------------------------------------------------------------
create table bookmaster(bname varchar(100),aname varchar(100),bookid int,status varchar(25))
select * from bookmaster
---------------------------------------------------------------------------------------------------------------------------
create table lendmaster(lname varchar(50),laddr varchar(100),doj datetime,email varchar(50),lendid int, status varchar(25))
select * from lendmaster
---------------------------------------------------------------------------------------------------------------------------
create table lenddetails(bname varchar(100),aname varchar(100),bookid int,lendid int,ldate datetime,rdate datetime)
select * from lenddetails
---------------------------------------------------------------------------------------------------------------------------
