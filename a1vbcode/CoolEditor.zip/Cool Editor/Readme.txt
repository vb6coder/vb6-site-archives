COOL EDITOR
===========

Simple editor with font and color support.
Also u can make log file and enter time.