User      |     Pass
==================
admin       admin123
operator   123
arizane     arissuryadi

the database file name is azbee.azb

change the extension with .mdb to view with access