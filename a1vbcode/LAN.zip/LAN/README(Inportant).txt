		    
                  #####################################
		  #				      #
		  #Developer: Mali Sandeep Sampatrao  #
                  #Email: baju_san@rediffmail.com     #
		  #       baju_san@yahoo.com                            #
		  #####################################
 	 
	Excellent code for beginners learning TCP/IP based 
	Communication.
	
	This program consists of two versions, client and server.
	Server must be running on remote machine, don�t worry it will 
	be invisible.

	Just run the client at any machine give the IP or host name of 
	the remote machine where that server is running and just 
	press any of command. you can put as many commands as u like, 
	I just tried to give some idea.

	Be careful about the shutdown command as it will force all apps 
	on remote machine to close.

	Keep in mind that most of commands like Paint and Notepad will 
	work only in Windows 2000 for Windows 98 just add a bit extra 
	code to find whether running Windows95/Windows98/XP.

	The software is freeware and can be used and converted as 
	required (but don�t forget for due credits).
	
	Send me information of modification about this software

	Do mail me for any comments and suggestions.
	 baju_san@rediffmail.com     
         baju_san@yahoo.com          
	
	###################
	#FUTURE ENHANCMENT#
	###################
	
	#1#	I want to convert BMP file into JPG format so
		Remote Desktop download process is reduce.
	#2#	

------------------------------------------------------------------
� Share your knowledge. It's the best way to achieve immortality. 
-ECLIPSE 3:16 �
------------------------------------------------------------------