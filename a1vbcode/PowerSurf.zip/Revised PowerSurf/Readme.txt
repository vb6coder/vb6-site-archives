**************************************************************************
*                         PowerSurf Explorer                             *
*                    For 32-bit Windows Environment                      *  
**************************************************************************


Information
==========================================================================
Product:       PowerSurf Explorer
Version:       1.0
Web Site:      http://www.angelfire.com/planet/powersurf/index.html
Email:         keen_coder@yahoo.com


Introduction
==========================================================================
PowerSurf Explorer  is an IE based Web browser, which means that  it  uses
some of the Internet Explorer Engine;   It incorporates a large collection
of wonderful  features like pop-up killer, filtering website or word, lock 
application, quick-search that allows you to search within the browser. It
brings you convenient and comfortable browsing.


Some of Great Features:
==========================================================================

Pop-Up Killer - allows you to Enable/Disable Pop-up Windows

Filtering - allows you to block all unwanted websites or word from accessing or viewing it, 
            specially those adult content sites.

Quick Search - Convenient access to major search engines..

Lock Application - block all unwanted users from accessing it while you were away from your PC.

Skins- allows you to change the skins according to your satisfaction.

WinMediaFx - you can play your favorite songs using the built-in Media Player.

Check New Version - ability to check for a new version of PowerSurf Explorer that has been released on the Internet. 


System Requirement
==========================================================================
- Win95+IE4 is the minimum requirement. Win98+IE5 is recommended. 
- PowerSurf Explorer runs on all 32-bit windows systems, i.e., Win95/98/ME/NT/2k/XP/2003/Vista. 
  A few minor features may not be available under win95. 

- Pentium Processor +
- 32 MB Memory +
- at least 8megabyte Hard Disk Space 
- 1024 x 768 Screen Resolution

Enjoy it!