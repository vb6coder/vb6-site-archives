Thank You For Choosing
			Hamza Software Deveploment

this is the program for managing the construction company 
it is my second which i have uploaded on planet-source-code and
sourcecodester. and i am not a good programmar so please give me
suggestions about my code so i can improve my coding standard. 
MUST VOTE FOR ME...THANK YOU

email: hamzajhang@yahoo.com
Phone: +923346320905