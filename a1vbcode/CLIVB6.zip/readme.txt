How to make command line parameters in your VB6 programs.

Created by Faleddo
http://blog.faleddo.cz.cc
http://xbeesoft.cz.cc