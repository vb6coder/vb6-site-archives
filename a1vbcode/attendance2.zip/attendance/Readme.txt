login : admin
password : admin
-----------------------------------------------------------------------
New Version Previous date bug removed
This project will help beginners for handling dates problem in access.
User can enter employee name in incoming form only once, next day user
need not be bother about typing names, he can select it from list.
Outgoing form only take name of those employees who has come on current
date.

Report form has a datagrid which is handling by the parameters.



