/*
SQLyog Ultimate v8.55 
MySQL - 5.0.45-community-nt : Database - pos_resto_bar
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`pos_resto_bar` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `pos_resto_bar`;

/*Table structure for table `access_level_` */

DROP TABLE IF EXISTS `access_level_`;

CREATE TABLE `access_level_` (
  `Access_ID` int(11) NOT NULL auto_increment,
  `Access_Desc` char(255) NOT NULL default '',
  `isDelete` int(1) NOT NULL default '0',
  PRIMARY KEY  (`Access_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `access_level_` */

insert  into `access_level_`(`Access_ID`,`Access_Desc`,`isDelete`) values (1,'Administrator',0),(2,'Cashier',0),(3,'Staff',0);

/*Table structure for table `billing_appetizers` */

DROP TABLE IF EXISTS `billing_appetizers`;

CREATE TABLE `billing_appetizers` (
  `bill_ID` int(11) NOT NULL auto_increment,
  `OSnum` int(11) NOT NULL,
  `App_ID` int(11) NOT NULL,
  `Qty` int(11) NOT NULL,
  `Totals` double NOT NULL,
  `Times` char(100) NOT NULL,
  `Dates` date NOT NULL,
  `Cashier_ID` int(11) NOT NULL,
  `Waiter_ID` int(11) NOT NULL,
  `Table_No` char(255) NOT NULL,
  `isDelete` int(1) NOT NULL default '0',
  `sumTotal_Amount` int(1) NOT NULL default '0',
  PRIMARY KEY  (`bill_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `billing_appetizers` */

insert  into `billing_appetizers`(`bill_ID`,`OSnum`,`App_ID`,`Qty`,`Totals`,`Times`,`Dates`,`Cashier_ID`,`Waiter_ID`,`Table_No`,`isDelete`,`sumTotal_Amount`) values (1,9381247,13,1,280,'09:08:11 PM','2011-08-21',1,7,'WQ',0,0),(2,9381247,16,1,290,'09:08:11 PM','2011-08-21',1,7,'WQ',1,0),(3,9381247,15,1,260,'09:08:11 PM','2011-08-21',1,7,'WQ',0,0);

/*Table structure for table `billing_beverages` */

DROP TABLE IF EXISTS `billing_beverages`;

CREATE TABLE `billing_beverages` (
  `Bill_ID` int(11) NOT NULL auto_increment,
  `OSnum` int(11) default NULL,
  `Bev_ID` int(11) default NULL,
  `Qty` int(11) default NULL,
  `Totals` double default NULL,
  `Times` char(200) default '',
  `Dates` date default NULL,
  `Cashier_ID` int(11) default NULL,
  `Waiter_ID` int(11) default NULL,
  `Table_No` char(255) default '',
  `isDelete` int(1) default '0',
  `SumTotal_Amount` int(1) NOT NULL default '0',
  PRIMARY KEY  (`Bill_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `billing_beverages` */

/*Table structure for table `category_` */

DROP TABLE IF EXISTS `category_`;

CREATE TABLE `category_` (
  `Category_ID` int(11) NOT NULL auto_increment,
  `Category_desc` char(255) NOT NULL,
  `isDelete` int(1) NOT NULL default '0',
  PRIMARY KEY  (`Category_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

/*Data for the table `category_` */

insert  into `category_`(`Category_ID`,`Category_desc`,`isDelete`) values (1,'Tequilla',0),(2,'Wine/Red',0),(3,'Wine/White',0),(4,'Sparkling Wine',0),(5,'Brandy',0),(6,'Rhum',0),(7,'Beverages',0),(8,'Cognac',0),(9,'Whisky',0),(10,'Cigarettes',0),(11,'Cocktails',0),(12,'Shakes',0),(13,'Margaritas',0),(14,'Martini',0),(15,'Vodka Mix',0),(16,'Gin Mix',0),(17,'Vodca/Bottle',0),(18,'Beers',0),(19,'Coolers',0);

/*Table structure for table `employees_` */

DROP TABLE IF EXISTS `employees_`;

CREATE TABLE `employees_` (
  `Employee_ID` int(11) NOT NULL auto_increment,
  `Employ_LN` char(100) NOT NULL,
  `Employ_FN` char(100) NOT NULL,
  `Employ_MI` char(5) NOT NULL,
  `Employ_DOB` date NOT NULL,
  `Employ_Add` char(255) NOT NULL,
  `Employ_CP` char(50) NOT NULL,
  `Employ_Position` int(11) NOT NULL,
  `isDelete` int(1) NOT NULL default '0',
  PRIMARY KEY  (`Employee_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `employees_` */

insert  into `employees_`(`Employee_ID`,`Employ_LN`,`Employ_FN`,`Employ_MI`,`Employ_DOB`,`Employ_Add`,`Employ_CP`,`Employ_Position`,`isDelete`) values (6,'Saldi','Lenie','S','2012-07-13','Repar Homes','0935846554',1,0),(7,'Saldi','Jc','C','2012-07-13','Asd','343',2,0);

/*Table structure for table `menu_appetizers_` */

DROP TABLE IF EXISTS `menu_appetizers_`;

CREATE TABLE `menu_appetizers_` (
  `App_ID` int(11) NOT NULL auto_increment,
  `App_Items` char(255) NOT NULL,
  `App_Size` int(11) NOT NULL default '6',
  `App_Amount` double NOT NULL,
  `isDelete` int(1) NOT NULL default '0',
  PRIMARY KEY  (`App_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `menu_appetizers_` */

insert  into `menu_appetizers_`(`App_ID`,`App_Items`,`App_Size`,`App_Amount`,`isDelete`) values (7,'Beef Salpicao',6,290,0),(8,'Tacos',6,260,0),(9,'Beef Fajitas',6,290,0),(10,'Nachos Supreme',6,315,0),(11,'Yam Yum Met',6,320,0),(12,'Chicken Buffalo Wings',6,280,0),(13,'Chicken Croquettes',6,280,0),(14,'Crackling Chicken Skin',6,210,0),(15,'Shrimp In Mango',6,260,0),(16,'Fritos Calamari',6,290,0);

/*Table structure for table `menu_beverages_` */

DROP TABLE IF EXISTS `menu_beverages_`;

CREATE TABLE `menu_beverages_` (
  `Bev_ID` int(11) NOT NULL auto_increment,
  `Category_ID` int(11) NOT NULL,
  `Bev_Desc` char(255) NOT NULL,
  `Bev_Size` int(11) default NULL,
  `Bev_Amount` double NOT NULL,
  `isDelete` int(1) NOT NULL default '0',
  PRIMARY KEY  (`Bev_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;

/*Data for the table `menu_beverages_` */

insert  into `menu_beverages_`(`Bev_ID`,`Category_ID`,`Bev_Desc`,`Bev_Size`,`Bev_Amount`,`isDelete`) values (1,5,'Fundador',1,2500,0),(2,5,'Carlos 1',3,140,0),(3,5,'Carlos 1',4,2500,0),(4,5,'Fundador',2,2100,0),(5,5,'Fundador',5,120,0),(6,5,'Torres 10',1,2800,0),(7,5,'Torres 10',2,2200,0),(8,5,'Torres 10',3,125,0),(9,1,'Tequilla Rose',2,2900,0),(10,1,'Tequilla Rose',3,120,0),(11,1,'Jose Cuervo',1,3600,0),(12,1,'Jose Cuervo',2,3200,0),(13,1,'Jose Cuervo',3,130,0),(14,6,'Baccardi Supperior',1,1800,0),(15,6,'Baccardi Supperior',3,110,0),(16,6,'Baccardi 151',1,2600,0),(17,6,'Baccardi 151',3,130,0),(18,6,'Baccardi Oro',1,1800,0),(19,6,'Baccardi Oro',3,110,0),(20,1,'Jose Cuervo Platino',2,7000,0),(21,1,'Jose Cuervo Platino',3,350,0),(22,1,'Patron XO',2,3800,0),(23,1,'Patron XO',3,200,0),(24,1,'Patron Reposado',3,350,0),(25,1,'Patron Reposado',2,7000,0),(26,8,'Remy Martin VSOP',1,6300,0),(27,8,'Remy Martin VSOP',3,320,0),(28,8,'Hennesy VSOP',1,8300,0),(29,8,'Hennesy VSOP',3,350,0),(30,8,'Hennesy XO',1,13000,0),(31,8,'Hennesy XO',3,400,0),(32,9,'Johnny Walker Black',1,3800,0),(33,9,'Johnny Walker Black',2,3400,0),(34,9,'Johnny Walker Black',3,140,0),(35,9,'Johnny Walker Green',2,5800,0),(36,9,'Johnny Walker Green',3,250,0),(37,9,'Johnny Walker Blue',2,15000,0),(38,9,'Johnny Walker Blue',3,600,0),(39,9,'Jack Daniels',1,3300,0),(40,9,'Jack Daniels',2,2800,0),(41,9,'Jack Daniels',3,120,0),(42,9,'Jim Beam',1,3000,0),(43,9,'Jim Beam',2,2600,0),(44,9,'Jim Beam',3,110,0),(45,2,'Hardys Cabarnet',4,1500,0),(46,2,'Hardys Cabarnet',5,300,0),(47,2,'Hardys Chivas',4,1500,0),(48,2,'Hardys Chivas',5,300,0),(49,2,'Hardys Merlot',5,1500,0),(50,2,'Hardys Merlot',5,300,0),(51,3,'Hardys Chardonnay',4,1500,0),(52,3,'Hardys Chardonnay',5,300,0),(53,4,'Astin Martin',4,1600,0),(54,18,'Redhorse',1,65,1),(55,18,'Redhorse',2,20,1);

/*Table structure for table `payment_appetizers` */

DROP TABLE IF EXISTS `payment_appetizers`;

CREATE TABLE `payment_appetizers` (
  `Payment_ID` int(11) NOT NULL auto_increment,
  `P_OSnum` int(11) NOT NULL,
  `P_Items_ID` int(11) NOT NULL,
  `P_Qty` int(11) NOT NULL,
  `P_Total_Amount` double NOT NULL,
  `P_Time` char(20) NOT NULL,
  `P_Date` date NOT NULL,
  `Cashier_ID` int(11) NOT NULL,
  `Waiter_ID` int(11) NOT NULL,
  `Customer_Name` char(255) NOT NULL default 'N/A',
  `Table_No` char(100) NOT NULL,
  `Remarks` char(100) NOT NULL,
  `isDelete` int(1) NOT NULL default '0',
  `sum_TotalAmount` int(1) NOT NULL default '0',
  `isCancel` int(1) NOT NULL default '0',
  PRIMARY KEY  (`Payment_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `payment_appetizers` */

insert  into `payment_appetizers`(`Payment_ID`,`P_OSnum`,`P_Items_ID`,`P_Qty`,`P_Total_Amount`,`P_Time`,`P_Date`,`Cashier_ID`,`Waiter_ID`,`Customer_Name`,`Table_No`,`Remarks`,`isDelete`,`sum_TotalAmount`,`isCancel`) values (1,22,8,1,260,'02:53:44 PM','2011-08-31',1,7,'Sa','WQ','UP',0,0,0),(2,32,16,1,290,'02:54:08 PM','2011-08-31',1,7,'N/A','QW','PD',0,0,0),(3,32,10,1,315,'12:20:53 PM','2011-09-01',1,7,'Wr','CC1','UP',0,0,0),(4,57,10,3,945,'10:11:52 PM','2011-09-04',1,7,'N/A','68','PD',0,0,0);

/*Table structure for table `payment_beverages` */

DROP TABLE IF EXISTS `payment_beverages`;

CREATE TABLE `payment_beverages` (
  `Payment_ID` int(11) NOT NULL auto_increment,
  `P_OSnum` int(11) NOT NULL,
  `P_Items_ID` int(11) NOT NULL,
  `P_Qty` int(11) NOT NULL,
  `P_Total_Amount` double NOT NULL,
  `P_Time` char(20) NOT NULL,
  `P_Date` date NOT NULL,
  `Cashier_ID` int(11) NOT NULL,
  `Waiter_ID` int(11) NOT NULL,
  `Customer_Name` char(255) NOT NULL default 'N/A',
  `Table_No` char(100) NOT NULL default '',
  `Remarks` char(100) NOT NULL,
  `isDelete` int(1) NOT NULL default '0',
  `Sum_TotalAmount` int(1) NOT NULL default '0',
  `isCancel` int(1) NOT NULL default '0',
  PRIMARY KEY  (`Payment_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `payment_beverages` */

insert  into `payment_beverages`(`Payment_ID`,`P_OSnum`,`P_Items_ID`,`P_Qty`,`P_Total_Amount`,`P_Time`,`P_Date`,`Cashier_ID`,`Waiter_ID`,`Customer_Name`,`Table_No`,`Remarks`,`isDelete`,`Sum_TotalAmount`,`isCancel`) values (1,34,7,1,2200,'10:58:34 AM','2011-08-31',1,7,'N/A','WE','PD',0,0,0),(2,123,31,1,400,'11:04:01 AM','2011-08-31',1,7,'N/A','DA','CANCELED',0,0,1),(3,343,31,1,400,'11:21:12 AM','2011-08-31',1,7,'Sd','WQ','PD',0,0,0),(4,324,28,1,8300,'08:52:25 PM','2011-08-21',1,7,'N/A','WQ','CANCELED',0,0,1),(5,324,14,1,1800,'08:52:25 PM','2011-08-21',1,7,'N/A','WQ','CANCELED',0,0,1),(6,324,5,1,120,'08:52:25 PM','2011-08-21',1,7,'N/A','WQ','CANCELED',0,0,1),(7,987,7,4,8800,'05:49:55 PM','2011-08-31',1,7,'Wr','CC1','UP',0,0,0);

/*Table structure for table `position_` */

DROP TABLE IF EXISTS `position_`;

CREATE TABLE `position_` (
  `Position_ID` int(11) NOT NULL auto_increment,
  `Position_Desc` char(255) NOT NULL,
  `isDelete` int(1) NOT NULL default '0',
  PRIMARY KEY  (`Position_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `position_` */

insert  into `position_`(`Position_ID`,`Position_Desc`,`isDelete`) values (1,'Cashier',0),(2,'Waiter',0);

/*Table structure for table `settings_` */

DROP TABLE IF EXISTS `settings_`;

CREATE TABLE `settings_` (
  `Setting_ID` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`Setting_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `settings_` */

/*Table structure for table `sign_chit_paid` */

DROP TABLE IF EXISTS `sign_chit_paid`;

CREATE TABLE `sign_chit_paid` (
  `sChit_ID` int(11) NOT NULL auto_increment,
  `Customer_Name` char(255) NOT NULL,
  `sChit_Date` date NOT NULL,
  `sChit_Balance` double NOT NULL,
  `Amount_PAID` double NOT NULL,
  `Date_Paid` date NOT NULL,
  `Time_Paid` char(100) NOT NULL,
  `isDelete` int(1) NOT NULL default '0',
  PRIMARY KEY  (`sChit_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `sign_chit_paid` */

insert  into `sign_chit_paid`(`sChit_ID`,`Customer_Name`,`sChit_Date`,`sChit_Balance`,`Amount_PAID`,`Date_Paid`,`Time_Paid`,`isDelete`) values (1,'N/A','2011-08-31',400,400,'2011-08-31','05:51:52 PM',0),(2,'Sd','2011-08-31',400,400,'2011-08-31','05:51:52 PM',0);

/*Table structure for table `size_` */

DROP TABLE IF EXISTS `size_`;

CREATE TABLE `size_` (
  `Size_ID` int(11) NOT NULL auto_increment,
  `Size_Desc` char(255) NOT NULL default '',
  `isDelete` int(1) NOT NULL default '0',
  PRIMARY KEY  (`Size_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `size_` */

insert  into `size_`(`Size_ID`,`Size_Desc`,`isDelete`) values (1,'1 Liter',0),(2,'750ml',0),(3,'Per Shot',0),(4,'Per Bottle',0),(5,'Per Glass',0),(6,'N/A',0);

/*Table structure for table `spoiled_osnum` */

DROP TABLE IF EXISTS `spoiled_osnum`;

CREATE TABLE `spoiled_osnum` (
  `OSnum` int(11) NOT NULL,
  `isDelete` int(1) NOT NULL default '0',
  PRIMARY KEY  (`OSnum`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `spoiled_osnum` */

insert  into `spoiled_osnum`(`OSnum`,`isDelete`) values (12332,0);

/*Table structure for table `temp_beverages` */

DROP TABLE IF EXISTS `temp_beverages`;

CREATE TABLE `temp_beverages` (
  `Bev_ID` int(11) NOT NULL,
  `Qty` int(11) NOT NULL,
  `ToTals` double NOT NULL,
  `isDelete` int(1) NOT NULL default '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `temp_beverages` */

/*Table structure for table `temp_chit_paid` */

DROP TABLE IF EXISTS `temp_chit_paid`;

CREATE TABLE `temp_chit_paid` (
  `Chit_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `temp_chit_paid` */

/*Table structure for table `tickets_` */

DROP TABLE IF EXISTS `tickets_`;

CREATE TABLE `tickets_` (
  `T_ID` int(11) NOT NULL auto_increment,
  `Date_Paid` date NOT NULL,
  `Customer_Name` char(255) NOT NULL,
  `Ticket_Amount` double NOT NULL,
  `Pax_Of` int(11) NOT NULL,
  `Total_Amounts` double NOT NULL,
  `isDelete` int(1) NOT NULL default '0',
  `sumTotal_Amount` int(1) NOT NULL default '0',
  PRIMARY KEY  (`T_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `tickets_` */

insert  into `tickets_`(`T_ID`,`Date_Paid`,`Customer_Name`,`Ticket_Amount`,`Pax_Of`,`Total_Amounts`,`isDelete`,`sumTotal_Amount`) values (1,'2011-09-04','As',113,1,113,0,0);

/*Table structure for table `total_amount` */

DROP TABLE IF EXISTS `total_amount`;

CREATE TABLE `total_amount` (
  `SumTotal_ID` int(1) NOT NULL default '0',
  `Total_Amount` double NOT NULL,
  `Total_Amount_UP` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `total_amount` */

insert  into `total_amount`(`SumTotal_ID`,`Total_Amount`,`Total_Amount_UP`) values (0,0,0);

/*Table structure for table `user_` */

DROP TABLE IF EXISTS `user_`;

CREATE TABLE `user_` (
  `User_ID` int(11) NOT NULL auto_increment,
  `User_Access` int(11) NOT NULL,
  `Employee_ID` int(11) NOT NULL,
  `User_UN` char(255) NOT NULL,
  `User_PW` char(255) NOT NULL,
  `isLogin` int(10) NOT NULL default '0',
  `isDelete` int(1) NOT NULL default '0',
  PRIMARY KEY  (`User_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `user_` */

insert  into `user_`(`User_ID`,`User_Access`,`Employee_ID`,`User_UN`,`User_PW`,`isLogin`,`isDelete`) values (1,1,6,'Lenie','Saldi',0,0),(2,1,7,'Saldi','Saldi',0,0);

/*Table structure for table `qry_appetizers` */

DROP TABLE IF EXISTS `qry_appetizers`;

/*!50001 DROP VIEW IF EXISTS `qry_appetizers` */;
/*!50001 DROP TABLE IF EXISTS `qry_appetizers` */;

/*!50001 CREATE TABLE  `qry_appetizers`(
 `App_ID` int(11) ,
 `App_Items` char(255) ,
 `Size_Desc` char(255) ,
 `App_Amount` double ,
 `Qty` int(11) ,
 `ToTals` double ,
 `isDelete` int(1) 
)*/;

/*Table structure for table `qry_beverages` */

DROP TABLE IF EXISTS `qry_beverages`;

/*!50001 DROP VIEW IF EXISTS `qry_beverages` */;
/*!50001 DROP TABLE IF EXISTS `qry_beverages` */;

/*!50001 CREATE TABLE  `qry_beverages`(
 `Bev_ID` int(11) ,
 `Bev_Desc` char(255) ,
 `Size_desc` char(255) ,
 `Bev_Amount` double ,
 `Qty` int(11) ,
 `ToTals` double ,
 `isDelete` int(1) 
)*/;

/*Table structure for table `qry_chit_paid` */

DROP TABLE IF EXISTS `qry_chit_paid`;

/*!50001 DROP VIEW IF EXISTS `qry_chit_paid` */;
/*!50001 DROP TABLE IF EXISTS `qry_chit_paid` */;

/*!50001 CREATE TABLE  `qry_chit_paid`(
 `Chit_ID` int(11) ,
 `Customer_Name` char(255) ,
 `sChit_Date` date ,
 `sChit_Balance` double ,
 `Amount_PAID` double ,
 `Date_Paid` date ,
 `Time_Paid` char(100) ,
 `isDelete` int(1) 
)*/;

/*Table structure for table `view_appetizers` */

DROP TABLE IF EXISTS `view_appetizers`;

/*!50001 DROP VIEW IF EXISTS `view_appetizers` */;
/*!50001 DROP TABLE IF EXISTS `view_appetizers` */;

/*!50001 CREATE TABLE  `view_appetizers`(
 `App_ID` int(11) ,
 `App_Items` char(255) ,
 `Size_Desc` char(255) ,
 `App_Amount` double ,
 `Size_ID` int(11) ,
 `isDelete` int(1) 
)*/;

/*Table structure for table `view_beverages` */

DROP TABLE IF EXISTS `view_beverages`;

/*!50001 DROP VIEW IF EXISTS `view_beverages` */;
/*!50001 DROP TABLE IF EXISTS `view_beverages` */;

/*!50001 CREATE TABLE  `view_beverages`(
 `Bev_ID` int(11) ,
 `Category_desc` char(255) ,
 `Bev_Desc` char(255) ,
 `Size_Desc` char(255) ,
 `Bev_Amount` double ,
 `Category_ID` int(11) ,
 `Size_ID` int(11) ,
 `isDelete` int(1) 
)*/;

/*Table structure for table `view_billing_appetizers` */

DROP TABLE IF EXISTS `view_billing_appetizers`;

/*!50001 DROP VIEW IF EXISTS `view_billing_appetizers` */;
/*!50001 DROP TABLE IF EXISTS `view_billing_appetizers` */;

/*!50001 CREATE TABLE  `view_billing_appetizers`(
 `Bill_ID` int(11) ,
 `Table_No` char(255) ,
 `OSnum` int(11) ,
 `App_Items` char(255) ,
 `Size_Desc` char(255) ,
 `App_Amount` double ,
 `Qty` int(11) ,
 `Totals` double ,
 `isDelete` int(1) ,
 `sumTotal_Amount` double ,
 `sumTotal_Amount_UP` double 
)*/;

/*Table structure for table `view_billing_beverages` */

DROP TABLE IF EXISTS `view_billing_beverages`;

/*!50001 DROP VIEW IF EXISTS `view_billing_beverages` */;
/*!50001 DROP TABLE IF EXISTS `view_billing_beverages` */;

/*!50001 CREATE TABLE  `view_billing_beverages`(
 `Bill_ID` int(11) ,
 `Table_No` char(255) ,
 `OSnum` int(11) ,
 `Category_desc` char(255) ,
 `Bev_Desc` char(255) ,
 `Size_Desc` char(255) ,
 `Bev_Amount` double ,
 `Qty` int(11) ,
 `Totals` double ,
 `isDelete` int(1) ,
 `sumTotal_Amount` double ,
 `sumTotal_Amount_UP` double 
)*/;

/*Table structure for table `view_employees` */

DROP TABLE IF EXISTS `view_employees`;

/*!50001 DROP VIEW IF EXISTS `view_employees` */;
/*!50001 DROP TABLE IF EXISTS `view_employees` */;

/*!50001 CREATE TABLE  `view_employees`(
 `Employee_ID` int(11) ,
 `Employ_LN` char(100) ,
 `Employ_FN` char(100) ,
 `Employ_MI` char(5) ,
 `Employ_DOB` date ,
 `Employ_Add` char(255) ,
 `Employ_CP` char(50) ,
 `Position_Desc` char(255) ,
 `Employ_Position` int(11) ,
 `isDelete` int(1) 
)*/;

/*Table structure for table `view_payment_appetizers` */

DROP TABLE IF EXISTS `view_payment_appetizers`;

/*!50001 DROP VIEW IF EXISTS `view_payment_appetizers` */;
/*!50001 DROP TABLE IF EXISTS `view_payment_appetizers` */;

/*!50001 CREATE TABLE  `view_payment_appetizers`(
 `Payment_ID` int(11) ,
 `P_OSnum` int(11) ,
 `App_Items` char(255) ,
 `Size_Desc` char(255) ,
 `App_Amount` double ,
 `P_Qty` int(11) ,
 `P_Total_Amount` double ,
 `P_Time` char(20) ,
 `P_Date` date ,
 `Assess_Person` varchar(201) ,
 `Waiters` varchar(201) ,
 `Customer_Name` char(255) ,
 `Table_No` char(100) ,
 `remarks` char(100) ,
 `isDelete` int(1) ,
 `isCancel` int(1) ,
 `sumTotal_Amount` double ,
 `sumTotal_Amount_UP` double 
)*/;

/*Table structure for table `view_payment_beverage` */

DROP TABLE IF EXISTS `view_payment_beverage`;

/*!50001 DROP VIEW IF EXISTS `view_payment_beverage` */;
/*!50001 DROP TABLE IF EXISTS `view_payment_beverage` */;

/*!50001 CREATE TABLE  `view_payment_beverage`(
 `Payment_ID` int(11) ,
 `P_OSnum` int(11) ,
 `Bev_Desc` char(255) ,
 `Size_Desc` char(255) ,
 `Bev_Amount` double ,
 `P_Qty` int(11) ,
 `P_Total_Amount` double ,
 `P_Time` char(20) ,
 `P_Date` date ,
 `Assess_Person` varchar(201) ,
 `Waiters` varchar(201) ,
 `Customer_Name` char(255) ,
 `Table_No` char(100) ,
 `remarks` char(100) ,
 `isDelete` int(1) ,
 `isCancel` int(1) ,
 `sumTotal_Amount` double ,
 `sumTotal_Amount_UP` double 
)*/;

/*Table structure for table `view_tickets` */

DROP TABLE IF EXISTS `view_tickets`;

/*!50001 DROP VIEW IF EXISTS `view_tickets` */;
/*!50001 DROP TABLE IF EXISTS `view_tickets` */;

/*!50001 CREATE TABLE  `view_tickets`(
 `T_ID` int(11) ,
 `Date_Paid` date ,
 `Customer_Name` char(255) ,
 `Ticket_Amount` double ,
 `Pax_Of` int(11) ,
 `Total_Amounts` double ,
 `isDelete` int(1) ,
 `Total_Amount` double 
)*/;

/*Table structure for table `view_user` */

DROP TABLE IF EXISTS `view_user`;

/*!50001 DROP VIEW IF EXISTS `view_user` */;
/*!50001 DROP TABLE IF EXISTS `view_user` */;

/*!50001 CREATE TABLE  `view_user`(
 `User_ID` int(11) ,
 `Employ_LN` char(100) ,
 `Employ_FN` char(100) ,
 `Employ_MI` char(5) ,
 `Access_Desc` char(255) ,
 `User_UN` char(255) ,
 `User_PW` char(255) ,
 `isLogin` int(10) ,
 `Employee_ID` int(11) ,
 `Access_ID` int(11) ,
 `isDelete` int(1) 
)*/;

/*View structure for view qry_appetizers */

/*!50001 DROP TABLE IF EXISTS `qry_appetizers` */;
/*!50001 DROP VIEW IF EXISTS `qry_appetizers` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `qry_appetizers` AS (select `menu_appetizers_`.`App_ID` AS `App_ID`,`menu_appetizers_`.`App_Items` AS `App_Items`,`size_`.`Size_Desc` AS `Size_Desc`,`menu_appetizers_`.`App_Amount` AS `App_Amount`,`temp_beverages`.`Qty` AS `Qty`,`temp_beverages`.`ToTals` AS `ToTals`,`temp_beverages`.`isDelete` AS `isDelete` from ((`temp_beverages` join `menu_appetizers_` on((`temp_beverages`.`Bev_ID` = `menu_appetizers_`.`App_ID`))) join `size_` on((`size_`.`Size_ID` = `menu_appetizers_`.`App_Size`)))) */;

/*View structure for view qry_beverages */

/*!50001 DROP TABLE IF EXISTS `qry_beverages` */;
/*!50001 DROP VIEW IF EXISTS `qry_beverages` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `qry_beverages` AS (select `menu_beverages_`.`Bev_ID` AS `Bev_ID`,`menu_beverages_`.`Bev_Desc` AS `Bev_Desc`,`size_`.`Size_Desc` AS `Size_desc`,`menu_beverages_`.`Bev_Amount` AS `Bev_Amount`,`temp_beverages`.`Qty` AS `Qty`,`temp_beverages`.`ToTals` AS `ToTals`,`temp_beverages`.`isDelete` AS `isDelete` from ((`menu_beverages_` join `temp_beverages` on((`menu_beverages_`.`Bev_ID` = `temp_beverages`.`Bev_ID`))) join `size_` on((`size_`.`Size_ID` = `menu_beverages_`.`Bev_Size`)))) */;

/*View structure for view qry_chit_paid */

/*!50001 DROP TABLE IF EXISTS `qry_chit_paid` */;
/*!50001 DROP VIEW IF EXISTS `qry_chit_paid` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `qry_chit_paid` AS (select `temp_chit_paid`.`Chit_ID` AS `Chit_ID`,`sign_chit_paid`.`Customer_Name` AS `Customer_Name`,`sign_chit_paid`.`sChit_Date` AS `sChit_Date`,`sign_chit_paid`.`sChit_Balance` AS `sChit_Balance`,`sign_chit_paid`.`Amount_PAID` AS `Amount_PAID`,`sign_chit_paid`.`Date_Paid` AS `Date_Paid`,`sign_chit_paid`.`Time_Paid` AS `Time_Paid`,`sign_chit_paid`.`isDelete` AS `isDelete` from (`sign_chit_paid` join `temp_chit_paid` on((`sign_chit_paid`.`sChit_ID` = `temp_chit_paid`.`Chit_ID`)))) */;

/*View structure for view view_appetizers */

/*!50001 DROP TABLE IF EXISTS `view_appetizers` */;
/*!50001 DROP VIEW IF EXISTS `view_appetizers` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_appetizers` AS (select `menu_appetizers_`.`App_ID` AS `App_ID`,`menu_appetizers_`.`App_Items` AS `App_Items`,`size_`.`Size_Desc` AS `Size_Desc`,`menu_appetizers_`.`App_Amount` AS `App_Amount`,`size_`.`Size_ID` AS `Size_ID`,`menu_appetizers_`.`isDelete` AS `isDelete` from (`size_` join `menu_appetizers_` on((`size_`.`Size_ID` = `menu_appetizers_`.`App_Size`)))) */;

/*View structure for view view_beverages */

/*!50001 DROP TABLE IF EXISTS `view_beverages` */;
/*!50001 DROP VIEW IF EXISTS `view_beverages` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_beverages` AS (select `menu_beverages_`.`Bev_ID` AS `Bev_ID`,`category_`.`Category_desc` AS `Category_desc`,`menu_beverages_`.`Bev_Desc` AS `Bev_Desc`,`size_`.`Size_Desc` AS `Size_Desc`,`menu_beverages_`.`Bev_Amount` AS `Bev_Amount`,`category_`.`Category_ID` AS `Category_ID`,`size_`.`Size_ID` AS `Size_ID`,`menu_beverages_`.`isDelete` AS `isDelete` from ((`category_` join `menu_beverages_` on((`category_`.`Category_ID` = `menu_beverages_`.`Category_ID`))) join `size_` on((`menu_beverages_`.`Bev_Size` = `size_`.`Size_ID`)))) */;

/*View structure for view view_billing_appetizers */

/*!50001 DROP TABLE IF EXISTS `view_billing_appetizers` */;
/*!50001 DROP VIEW IF EXISTS `view_billing_appetizers` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_billing_appetizers` AS (select `billing_appetizers`.`bill_ID` AS `Bill_ID`,`billing_appetizers`.`Table_No` AS `Table_No`,`billing_appetizers`.`OSnum` AS `OSnum`,`menu_appetizers_`.`App_Items` AS `App_Items`,`size_`.`Size_Desc` AS `Size_Desc`,`menu_appetizers_`.`App_Amount` AS `App_Amount`,`billing_appetizers`.`Qty` AS `Qty`,`billing_appetizers`.`Totals` AS `Totals`,`billing_appetizers`.`isDelete` AS `isDelete`,`total_amount`.`Total_Amount` AS `sumTotal_Amount`,`total_amount`.`Total_Amount_UP` AS `sumTotal_Amount_UP` from (((`menu_appetizers_` join `billing_appetizers` on((`menu_appetizers_`.`App_ID` = `billing_appetizers`.`App_ID`))) join `size_` on((`size_`.`Size_ID` = `menu_appetizers_`.`App_Size`))) join `total_amount` on((`total_amount`.`SumTotal_ID` = `billing_appetizers`.`sumTotal_Amount`)))) */;

/*View structure for view view_billing_beverages */

/*!50001 DROP TABLE IF EXISTS `view_billing_beverages` */;
/*!50001 DROP VIEW IF EXISTS `view_billing_beverages` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_billing_beverages` AS (select `billing_beverages`.`Bill_ID` AS `Bill_ID`,`billing_beverages`.`Table_No` AS `Table_No`,`billing_beverages`.`OSnum` AS `OSnum`,`category_`.`Category_desc` AS `Category_desc`,`menu_beverages_`.`Bev_Desc` AS `Bev_Desc`,`size_`.`Size_Desc` AS `Size_Desc`,`menu_beverages_`.`Bev_Amount` AS `Bev_Amount`,`billing_beverages`.`Qty` AS `Qty`,`billing_beverages`.`Totals` AS `Totals`,`billing_beverages`.`isDelete` AS `isDelete`,`total_amount`.`Total_Amount` AS `sumTotal_Amount`,`total_amount`.`Total_Amount_UP` AS `sumTotal_Amount_UP` from ((((`menu_beverages_` join `billing_beverages` on((`menu_beverages_`.`Bev_ID` = `billing_beverages`.`Bev_ID`))) join `size_` on((`size_`.`Size_ID` = `menu_beverages_`.`Bev_Size`))) join `category_` on((`category_`.`Category_ID` = `menu_beverages_`.`Category_ID`))) join `total_amount` on((`total_amount`.`SumTotal_ID` = `billing_beverages`.`SumTotal_Amount`)))) */;

/*View structure for view view_employees */

/*!50001 DROP TABLE IF EXISTS `view_employees` */;
/*!50001 DROP VIEW IF EXISTS `view_employees` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_employees` AS (select `employees_`.`Employee_ID` AS `Employee_ID`,`employees_`.`Employ_LN` AS `Employ_LN`,`employees_`.`Employ_FN` AS `Employ_FN`,`employees_`.`Employ_MI` AS `Employ_MI`,`employees_`.`Employ_DOB` AS `Employ_DOB`,`employees_`.`Employ_Add` AS `Employ_Add`,`employees_`.`Employ_CP` AS `Employ_CP`,`position_`.`Position_Desc` AS `Position_Desc`,`employees_`.`Employ_Position` AS `Employ_Position`,`employees_`.`isDelete` AS `isDelete` from (`employees_` join `position_` on((`employees_`.`Employ_Position` = `position_`.`Position_ID`)))) */;

/*View structure for view view_payment_appetizers */

/*!50001 DROP TABLE IF EXISTS `view_payment_appetizers` */;
/*!50001 DROP VIEW IF EXISTS `view_payment_appetizers` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_payment_appetizers` AS (select `payment_appetizers`.`Payment_ID` AS `Payment_ID`,`payment_appetizers`.`P_OSnum` AS `P_OSnum`,`menu_appetizers_`.`App_Items` AS `App_Items`,`size_`.`Size_Desc` AS `Size_Desc`,`menu_appetizers_`.`App_Amount` AS `App_Amount`,`payment_appetizers`.`P_Qty` AS `P_Qty`,`payment_appetizers`.`P_Total_Amount` AS `P_Total_Amount`,`payment_appetizers`.`P_Time` AS `P_Time`,`payment_appetizers`.`P_Date` AS `P_Date`,concat(`view_user`.`Employ_FN`,_latin1' ',`view_user`.`Employ_LN`) AS `Assess_Person`,concat(`employees_`.`Employ_FN`,_latin1' ',`employees_`.`Employ_LN`) AS `Waiters`,`payment_appetizers`.`Customer_Name` AS `Customer_Name`,`payment_appetizers`.`Table_No` AS `Table_No`,`payment_appetizers`.`Remarks` AS `remarks`,`payment_appetizers`.`isDelete` AS `isDelete`,`payment_appetizers`.`isCancel` AS `isCancel`,`total_amount`.`Total_Amount` AS `sumTotal_Amount`,`total_amount`.`Total_Amount_UP` AS `sumTotal_Amount_UP` from (((((`payment_appetizers` join `menu_appetizers_` on((`payment_appetizers`.`P_Items_ID` = `menu_appetizers_`.`App_ID`))) join `size_` on((`size_`.`Size_ID` = `menu_appetizers_`.`App_Size`))) join `view_user` on((`view_user`.`User_ID` = `payment_appetizers`.`Cashier_ID`))) join `employees_` on((`employees_`.`Employee_ID` = `payment_appetizers`.`Waiter_ID`))) join `total_amount` on((`payment_appetizers`.`sum_TotalAmount` = `total_amount`.`SumTotal_ID`)))) */;

/*View structure for view view_payment_beverage */

/*!50001 DROP TABLE IF EXISTS `view_payment_beverage` */;
/*!50001 DROP VIEW IF EXISTS `view_payment_beverage` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_payment_beverage` AS (select `payment_beverages`.`Payment_ID` AS `Payment_ID`,`payment_beverages`.`P_OSnum` AS `P_OSnum`,`menu_beverages_`.`Bev_Desc` AS `Bev_Desc`,`size_`.`Size_Desc` AS `Size_Desc`,`menu_beverages_`.`Bev_Amount` AS `Bev_Amount`,`payment_beverages`.`P_Qty` AS `P_Qty`,`payment_beverages`.`P_Total_Amount` AS `P_Total_Amount`,`payment_beverages`.`P_Time` AS `P_Time`,`payment_beverages`.`P_Date` AS `P_Date`,concat(`view_user`.`Employ_FN`,_latin1' ',`view_user`.`Employ_LN`) AS `Assess_Person`,concat(`employees_`.`Employ_FN`,_latin1' ',`employees_`.`Employ_LN`) AS `Waiters`,`payment_beverages`.`Customer_Name` AS `Customer_Name`,`payment_beverages`.`Table_No` AS `Table_No`,`payment_beverages`.`Remarks` AS `remarks`,`payment_beverages`.`isDelete` AS `isDelete`,`payment_beverages`.`isCancel` AS `isCancel`,`total_amount`.`Total_Amount` AS `sumTotal_Amount`,`total_amount`.`Total_Amount_UP` AS `sumTotal_Amount_UP` from (((((`payment_beverages` join `menu_beverages_` on((`payment_beverages`.`P_Items_ID` = `menu_beverages_`.`Bev_ID`))) join `size_` on((`size_`.`Size_ID` = `menu_beverages_`.`Bev_Size`))) join `view_user` on((`view_user`.`User_ID` = `payment_beverages`.`Cashier_ID`))) join `employees_` on((`employees_`.`Employee_ID` = `payment_beverages`.`Waiter_ID`))) join `total_amount` on((`payment_beverages`.`Sum_TotalAmount` = `total_amount`.`SumTotal_ID`)))) */;

/*View structure for view view_tickets */

/*!50001 DROP TABLE IF EXISTS `view_tickets` */;
/*!50001 DROP VIEW IF EXISTS `view_tickets` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_tickets` AS (select `tickets_`.`T_ID` AS `T_ID`,`tickets_`.`Date_Paid` AS `Date_Paid`,`tickets_`.`Customer_Name` AS `Customer_Name`,`tickets_`.`Ticket_Amount` AS `Ticket_Amount`,`tickets_`.`Pax_Of` AS `Pax_Of`,`tickets_`.`Total_Amounts` AS `Total_Amounts`,`tickets_`.`isDelete` AS `isDelete`,`total_amount`.`Total_Amount` AS `Total_Amount` from (`total_amount` join `tickets_` on((`total_amount`.`SumTotal_ID` = `tickets_`.`sumTotal_Amount`)))) */;

/*View structure for view view_user */

/*!50001 DROP TABLE IF EXISTS `view_user` */;
/*!50001 DROP VIEW IF EXISTS `view_user` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_user` AS (select `user_`.`User_ID` AS `User_ID`,`employees_`.`Employ_LN` AS `Employ_LN`,`employees_`.`Employ_FN` AS `Employ_FN`,`employees_`.`Employ_MI` AS `Employ_MI`,`access_level_`.`Access_Desc` AS `Access_Desc`,`user_`.`User_UN` AS `User_UN`,`user_`.`User_PW` AS `User_PW`,`user_`.`isLogin` AS `isLogin`,`employees_`.`Employee_ID` AS `Employee_ID`,`access_level_`.`Access_ID` AS `Access_ID`,`user_`.`isDelete` AS `isDelete` from ((`access_level_` join `user_` on((`access_level_`.`Access_ID` = `user_`.`User_Access`))) join `employees_` on((`user_`.`Employee_ID` = `employees_`.`Employee_ID`)))) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
