Just wanted to share this to the world as a gratitude. I alone cant complete this all, without the face figure to see where to start on. So thank you guys who ever you are!

This program is created for the thesis by the STI team group 3.
Course and Section: DIT 2-1C

The following members are listed below

Jose Paolo Miguel N.Espinosa - Prgorammer/Designer/Analyst
Merely A. Badiang - Data source
Judy S. Dano - Documentation
Phrecy love Milvar- Documentation
Joy N. Fabre - Watcher/Book binding compiler

The program was being tested and 99% running. It includes some dummy employee inside, for you to test.

				Admin account
                            -----------------------------
                            |                           | 
                            |   login:    Bossing       |
                            |   Password: 143intercore  |
                            |  			        |
                            -----------------------------

				Employee account
                            -------------------------
                            |                       | 
                            |  login:(Employee name)|
                            |  Password: 1234       |
                            |  			    |
                            -------------------------


This porgram is automatically compute the employee salary. Working days are counted every login and the source of computation on every employee. you wonder why the employee gross are all '0'. to adjust the working days on every employee, please open 'DATA1.mdb', 'Employee' table, and look for the 'workingdays' at the fields. 


For any question regarding on the program, please dont hesitate to contact me!

granparanoia@gmail.com
raisencross@gmail.com



Ocotber 30, 2008

-Raisen��