default password: 1234

for inquiry, questions or for source code, please e-mail me. 

granparanoia@gmail.com	
raisencross@gmail.com
