create table bloodbank
(name varchar2(20),
age number(2) check(age>18),
sex char(6),
addr char(20) not null,
b_group char(4) not null, 
phno number(15)
);



insert into bloodbank values ('adil',21,'M',' ALIGARH ','B+',9875684238)
;

insert into bloodbank values ('mann',20,'M','DASAULI','O-',9648721649)
;

insert into bloodbank values ('avi',23,'F','DALI-GANJ','A-',9247851683)
;


insert into bloodbank values ('bean',23,'F','MANIK NAGAR','A-',9335478941)
;
commit;













commit;