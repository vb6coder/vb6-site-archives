create table patientadmit
(id_no number(5) primary key,
pname varchar2(40) NOT NULL,
class varchar2(30),
bed_no number(3),
medicine varchar2(25),
disease varchar2(19), 
doc_name varchar2(20) NOT NULL,
date_ad date
);



insert into patientadmit
values(904,'Rohan','Minor Injury',21,'Cobadex','Gum Infection','Dr. BEAN','01-FEB-08');


insert into patientadmit
values(909,'Ashish','Cardiology',23,'Heartlock','Heartstroke','Dr. KHAN','21-may-08');


insert into patientadmit
values(843,'Ankit','Plastic Surgery',43,'antriozone','Anemia','Dr. AVI','14-jul-08');


insert into patientadmit
values(740,'Bilal','Neurology',78,'Dizn50','Internal Bleeding','Dr. MANI','12-aug-08');

commit;
