create table staffinfo
(name varchar2(25),
sex char(1),
age number(2),
address varchar2(20),
designation char(15),
phno number(15),
j_date date,
id char(4) primary key
);

 insert into staffinfo values ('PAVAN','M',35,'ALIGANJ','SWEEPER',2456789,'02-jan-07',601)
 ;

 insert into staffinfo values ('PALAVE','F',35,'ALIGANJ','NURSE',2478429,'02-jan-07',802)
 ;


insert into staffinfo values ('SARA','F',30,'ALIGANJ','RECEPTIONIST',2478460,'09-jun-09',503)
 ;



commit;
