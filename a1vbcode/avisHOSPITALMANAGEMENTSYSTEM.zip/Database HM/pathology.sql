create table pathology
(x_rays varchar2(20),
u_sound varchar2(20),
b_test varchar2(20),
ct_scan varchar2(20),
pname  varchar2(25),
id  number(5) not null,
sex char(6),
age number(2)
) ;



 insert into pathology values ('Positive','Negative','AB+','Negative','Mahfooz',1,'M',56);


 insert into pathology values ('Negative','Negative','A+','Negative','Ajaz',2,'M',24);

 insert into pathology values ('Positive','Negative','B-','Positive','Saleem',3,'M',30);



 insert into pathology values ('Positive','Positive','B+','Positive','Pinki',3,'F',28)


commit;
