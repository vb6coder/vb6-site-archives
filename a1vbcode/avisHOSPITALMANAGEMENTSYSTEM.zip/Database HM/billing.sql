 create table billing 
 (
 bill_no number(5) not null,
 id number(5) primary key,
 pname varchar2(25),
 class varchar2(20),
 ot_charge number(7),
 pathology number(7),
 misc number(7),
 ent_date date,
 dis_date date
 );





insert into billing
values(19,802,'adi','HEAD INJURY',900,5000,300,'30-MAY-07','21-FEB-08');


insert into billing
values(12,01,'mani','CARDIOLOGY',5000,784,1200,'01-JUN-07','19-DEC-07');


insert into billing
values(30,04,'avi','NEUROLOGY',4951,7414,650,'14-OCT-07','04-NOV-07');



commit;