create table patiententry
(id_no number(5) primary key,
pname varchar2(40) NOT NULL,
sex char(6),
age number(2),
bgroup char(4),
phno number(15),
rea_of_visit varchar2(25),
doc_name char(20) NOT NULL
);


insert into patiententry values(04,'bean','M',21,'A+',9876543210,'gum problem','DR.OMI')
;


insert into patiententry values(05,'khan','M',20,'O+',9336618898,'Cancer','DR.Juhi')
;



insert into patiententry values(06,'MANISH','M',18,'O-',9889031310,'CANCER',' DR.Rahul')
;



insert into patiententry values(07,'mani','F',25,'O+',9874563210,'Head injury','DR.Saran')
;


insert into patiententry values(08,'avi','M',28,'A+',9795379939,'aviphobia','DR.Juhi')
;


commit;
