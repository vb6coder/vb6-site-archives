Making a FORM Transparent

Requires Windows 2000, XP, XP SP2 or higher...
Windows 9x and Me are not supportable.

true_innocent_hero@yahoo.com