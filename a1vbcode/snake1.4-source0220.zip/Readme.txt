Snake v1.4
===========

by Syed Zainudeen Mohd Shaid. (February 2010).

New in version 1.4?
- Improved AI engine for computer mode
- Snake length can grow up to 60
- Game speed changes depending on the amount of fruit consumed


History:
--------

version 1.3 - Experimental version (unreleased)
(2008)      - Improved AI engine for computer mode

version 1.2 - Corrected some bugs detected in version 1.1
(2008)      - Dual mode gameplay (computer mode and human mode)

Version 1.1 - Experimental version (unreleased).
(2008)      - Includes a simple AI engine for computer mode.
            - Snake length set to 4.
            - No more world oriented map. Map now has borders and obstacles to make gameplay a bit for fun.

Version 1.0 - Game ini aku develop guna VB6.0 untuk pertandingan tACT06.
(2006)      - NAk main senang je.. korang copy folder ni ke hard disk, USB drive atau sebarang media
              yang boleh baca dan tulis (read and write).
            - simple snake game without borders/obstacles.

-------------------------------------- 
Copyright �2006-2010, Syed Zainudeen Mohd Shaid. All rights reserved.