Create database Invoice
use Invoice

create table Login
(Password varchar(15))

insert into Login values
('invoice')

select * from login

create table CustomerE
( CustomerID integer identity,
CustomerName char(30),
CustomerAddress char(50),
District Char(20),
Post char(20),
State char(20),
Pin integer,
primary key (CustomerID))

insert into CustomerE values
('Name','Address','District','Post','State',0)

create table CustomerD
( CustomerID integer identity,
CustomerName char(30),
CustomerAddress char(50),
District Char(20),
Post char(20),
State char(20),
Pin integer,
primary key (CustomerID))

select * from customere
select * from customerd

create table Bill
(BillID integer identity,
Date_Now varchar(15),
CustomerName char(30),
Address char(50),
Post char(20),
District char(20),
State char(20),
Pin integer,
ItemName1 char(50),
ItemCode1 integer,
Quantity1 integer,
Price1 integer,
ItemName2 char(50),
ItemCode2 integer,
Quantity2 integer,
Price2 integer,
ItemName3 char(50),
ItemCode3 integer,
Quantity3 integer,
Price3 integer,
ItemName4 char(50),
ItemCode4 integer,
Quantity4 integer,
Price4 integer,
ItemName5 char(50),
ItemCode5 integer,
Quantity5 integer,
Price5 integer,
ItemName6 char(50),
ItemCode6 integer,
Quantity6 integer,
Price6 integer,
ItemName7 char(50),
ItemCode7 integer,
Quantity7 integer,
Price7 integer,
ItemName8 char(50),
ItemCode8 integer,
Quantity8 integer,
Price8 integer,
ItemName9 char(50),
ItemCode9 integer,
Quantity9 integer,
Price9 integer,
ItemName10 char(50),
ItemCode10 integer,
Quantity10 integer,
Price10 integer,
Vat integer,
Total integer,
Payment_Option char(15),
Profit integer)


select * from bill

create table SupplierE
(SupplierID integer identity,
SupplierName char(30),
SupplierAddress char(50),
City Char(20),
Post char(20),
State char(20),
Pin integer,
primary key (SupplierID))

insert into suppliere values
('Name','Address','City','Post','State',1)

create table SupplierD
(SupplierID integer identity,
SupplierName char(30),
SupplierAddress char(50),
City Char(20),
Post char(20),
State char(20),
Pin integer,
primary key (SupplierID))



insert into supplierd values
('Eastern Logica','38 Chadni Chawk','Kolkata','Chadni Chawk','West Bengal',700012)

insert into supplierd values
('Sabu Computers','39 Chadni Chawk','Kolkata','Chadni Chawk','West Bengal',700012)

insert into supplierd values
('Supreme Computers','24 Chadni Chawk','Kolkata','Chadni Chawk','West Bengal',700012)

insert into supplierd values
('Dutta Infotech','36 K.G.R. Path','Kanchrapara','Kanchrapara','West Bengal',743145)


select * from supplierd
select * from suppliere


create table Items
(ItemName char(50),
ItemCode integer identity,
Price integer,
primary key (ItemCode))

create table Stock
(ItemName char(50),
ItemCode integer identity,
Price integer,
Quantity integer,
primary key (ItemCode))

insert into Items values
('Intel 945 GC',4231)
insert into Items values
('intel 102-GC2',9542)
insert into Items values
('BioStar945 Micro 755',2460)
insert into Items values
('BioStar945 Micro 775 Mother Board',2680)
insert into Items values
('ASUS Mother Board',2600)
insert into Items values
('Intex 401VTX',1620)
insert into Items values
('Intex 220VLT',1856)
insert into Items values
('Intex 4562I',1847)
insert into Items values
('Intex A00125L',2563)
insert into Items values
('Supercomp 345VPIL',2130)
insert into Items values
('Supercomp A0098I',1620)
insert into Items values
('Techcom B0098X',2355)
insert into Items values
('Supercomp B0000124',2800)
insert into Items values
('Intel Pentium D',4500)
insert into Items values
('Intel Pentium D2',4612)
insert into Items values
('Intel Pentium III',3826)
insert into Items values
('Intel Pentium IV',4956)
insert into Items values
('Sheleron Micro',2630)
insert into Items values
('AMD Athlon 2000',2600)
insert into Items values
('AMD Athlon 2200',2720)
insert into Items values
('AMD Athlon 2400',2800)
insert into Items values
('AMD Athlon 2800',3400)
insert into Items values
('AMD Athlon 3200',4215)
insert into Items values
('Supercomp 436X Web Camera',235)
insert into Items values
('Supercomp 450IX Web Camera',435)
insert into Items values
('Techcom 220L Web Camera',336)
insert into Items values
('Techcom 430L Web Camera',730)
insert into Items values
('Supercomp 7LED Web Camera',856)
insert into Items values
('HP ColorLab Scanner',2400)
insert into Items values
('Dell ColorScan Scanner',3600)
insert into Items values
('HP ColorDeskjet 3840 Printer',3600)
insert into Items values
('HP PhotoPrint 3844 Printer',3820)
insert into Items values
('HP ColorInkjet 4200',3400)
insert into Items values
('NVIDIA Geforce 8500',3900)
insert into Items values
('NVIDIA Geforce XFX',3850)
insert into Items values
('NVIDIA 8200',3654)
insert into Items values
('Techcom 2400 Sound Card',2200)
insert into Items values
('Techcom 2600 Sound Card',2460)
insert into Items values
('Supercomp 2200 Sound Card',2500)
insert into Items values
('Supercomp 10000 Sound Card',4230)
insert into Items values
('supercomp 12000 Sound Card',4650)
insert into Items values
('Supercom 2000 Woofer',1200)
insert into Items values
('Supercom 2400 Woofer',1420)
insert into Items values
('Frontech 2200 Woofer',1600)
insert into Items values
('Frontech 2800 Woofer',2200)
insert into Items values
('Techcom 2460 Woofer',2120)
insert into Items values
('Techcom 10000 Woofer',3200)
insert into Items values
('Creative 2.1 Woofer',2512)
insert into Items values
('Creative 4.1 Woofer',4100)
insert into Items values
('Creative 5.1 Woofer',5230)
insert into Items values
('Atlanta 4.1 Woofer',4652)
insert into Items values
('Odessey Keyboard',210)
insert into Items values
('Supercomp Keyboard',220)
insert into Items values
('Techcom Keyboard',260)
insert into Items values
('Odessey Mouse',230)
insert into Items values
('Supercomp Mouse',245)
insert into Items values
('Supercomp Cordless Mouse',4200)
insert into Items values
('Xtreme PCTV',1550)
insert into Items values
('Xterme PCTV 1200',2200)
insert into Items values
('Palmtop TV',3800)
insert into Items values
('IBall MBenz Cabinet',1500)
insert into Items values
('IBall Nano Cabinet',1630)
insert into Items values
('Techcom Prosserio Cabinet',1400)
insert into Items values
('Frontech Combo Cabinet',1620)
insert into Items values
('Dataone ADSL',1400)
insert into Items values
('DLink ADSL',1450)
insert into Items values
('DLink Internal',1200)
insert into Items values
('Samsung HDD 120GB',1200)
insert into Items values
('Samsung HDD 80GB',900)
insert into Items values
('Samsung HDD 40GB',1400)
insert into Items values
('samsung HDD 160GB',1600)
insert into Items values
('Samsung HDD 250GB',1800)
insert into Items values
('Seagate HDD 120GB',1400)
insert into Items values
('Seagate HDD 80GB',1200)
insert into Items values
('Seagate HDD 40GB',1000)
insert into Items values
('Seagate  HDD 160GB',1650)
insert into Items values
('Seagate HDD 250GB',1820)
insert into Items values
('Samsung FDD',450)
insert into Items values
('Samsung CDD',1200)
insert into Items values
('Samsung Combo',1500)
insert into Items values
('Samsung DVD Burner',1650)
insert into Items values
('Supercomp Card Reader',210)
insert into Items values
('Supercomp Bluetooth',300)
insert into Items values
('Supercomp USB_HUB',220)
insert into Items values
('Supercomp Single USB',75)
insert into Items values
('Intel Core Duo T2350 Laptop',40900)
insert into Items values
('Intel PD 3.0 GHZ Laptop',34500)
insert into Items values
('AamarPC D10T Computer',32050)
insert into Items values
('AamarPC FH0987J Computer',27050)
insert into Items values
('Dell Compac N60I Computer',29230)
insert into Items values
('Dell N10T Computer',32150)
insert into Items values
('HP Super02 Computer',32050)
insert into Items values
('HP NormalPC Computer',24160)
insert into Items values
('IBM 01N40P Computers',32050)
insert into Items values
('IBM 02N50P Computers',36050)


select * from items
select * from stock