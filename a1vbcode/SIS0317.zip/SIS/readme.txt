user: admin	
password: admin

Program created by: Eduard Due�as
E-Mail:  Eduaxs@yahoo.com