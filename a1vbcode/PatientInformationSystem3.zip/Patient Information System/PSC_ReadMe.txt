Title: Patient's Information System v1.0
Description: The system is about organizing and maintaining the medical records of all patients. The program uses ADO and lots of user-defined functions to improve visual basic. The system is very intelligent that it can automatically determine if a record is for new or edit or delete. Therefore, the Add New, Edit, Cancel and Delete Buttons are reduced into 2 buttons only to minimize user's work and also maximize time efficiency. The following are some capabilities of the program:
1. It uses DAO technology to manipulate the databases. 
2. Handle millions of records.
3. Uses very flexible search form.
4. Designed as professional looking software. 
5. Use custom define procedures and functions to optimize your program execution. 
6. Use of string and file manipulation to adopt different file locations. 
7. Use API to improve functionalities.
8. USE THE PROGRAM TO KNOW MORE.

There are lot things to learn from this code so please try it and vote if you learned something from it. Thanks! 

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62781&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
