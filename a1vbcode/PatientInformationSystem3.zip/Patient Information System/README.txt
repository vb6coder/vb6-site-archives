PATIENT'S INFORMATION SYSTEM V1.0

.: DEVELOPER :.
----------------------------------
Programmer: Jeffrey I. Lim
Address: Philippines/Washington
Cell##: +63 921 825-9455
Office#: +63 75 523-4061
E-mail: jil821@yahoo.com
Website: http://www.pcland.cjb.net

.: APPLICATION :.
-----------------------------------
[Log-in]
- UserName: admin
- Password: admin

.: MESSAGE :.
-----------------------------------
- Several number of students are submitting this work as their Thesis Project in Colleges and I've plenty of mails from them. And I adviced not to do so 'coz if inquiry is done, you will definitely be in trouble, so please use it for learning and research purposes only.
- Should you need my service, kindly contact me from the above-mentioned contact info.
- Hi to all my friends in Washington namely Glenn, Pastor Josh, JB, Gina, Biernes, Dix, Ulcing, Babs, George, Kuya Ed, Ate Penny, Con & Mike, Lynn & Madeline (my cousins), Pards & Karen of California, and All my friends in the Philippines, Al, Rey, Barry, Bax and especially my family.




