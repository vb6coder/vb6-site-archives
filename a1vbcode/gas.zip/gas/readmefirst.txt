This project is created for live purpose it is currently running in an Indan Gas Agency in Delhi.It is nice plz try this.

NOTE:
************************************************************
For running this project plz create a DSN as named "GASDATA" 
with consumer database that is exist with folder

************************************************************

Bye Enjoy

Create By: Lokesh Kumar
Mail: lokeshnow@yahoo.com
