Key logger : Created By vishnu ks 
email me at :appu007ks@gamil.com



The program pack contain one project file (key) ,one module (edit) and a log reader
This application can catch all the alphabets,numerals(numpad) and store the data in a txt file
, the attached exe logreader can use to read the log .
the original log file is dificult to read (not encrypted) because each letters is in each line
the log reader will make it in readable form.



