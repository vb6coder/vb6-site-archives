Pleaase Note:

A) I have modified the code of this project from an earlier submission at PSC almost entirely and thus generated a new project of my own.

B) I have used two ActiveX controls in this project which can be downloaded from PSC. Because the PSC doesn't allow submitting ActiveX controls hence get these files downloaded from PSC or send me a mail.

C) Default LOGIN Details [For this project]:

	a) Administrative User:		
		Username: admin
		Pwd: admin

	b) Non-Administrative User:			
		Username: demo
		Pwd: demo

D) Finally, please don't forget to vote for me..!! 

[I have developed some more projects the code for which I'm going to submit soon in the PSC. The screenshot which has been submitted for this project is my forthcoming project, which will be submitted as soon as the project is completed.]

