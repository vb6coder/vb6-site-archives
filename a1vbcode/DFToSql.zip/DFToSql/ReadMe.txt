Dera friends this is a sample demo of how to get data from .dbf file to do follow given steps.

>>> Creat a new DataBase called Test in Sql 7
>>> Import any .dbf file to SQL Database (only for structure puprose)
now you can import any data from .dbf file to Sql 7, u can creat your own data 
and save as per your requirements

also you can export data from grid to .CSV / .XLS format this small module you can use for various purpose i.e.

1.how to use ini file using VB 
2.How to get data from ant .dbf file 
3.how to export data to .xls, .csv format


Thankx


Kumar S Patil


