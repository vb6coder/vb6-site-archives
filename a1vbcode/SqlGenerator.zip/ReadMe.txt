SQL Generator for Visual Basic and VBA


This application allows you to quickly build an industrial strength database program, and adds many safeguards and features that you would otherwise have to code for yourself.  The app accepts database schema definitions in the form of an XML file and generates all of the code necessary to access SQL databases in the form of a VB module that you insert into your application.  Operations that are performed for you include the following:

* Handles all of the issues related to initialization strings and opening the database(s).

* Generates correctly formatted SQL statements for both queries and updates (errors are caught at generation time rather than when the code is run).  You can rerun the generator at any time when the schema changes, and the code will then always be correct.

* Handles SQL error recovery, display, and logging of errors automatically.

* Deals with many SQL gotchas, such as escaping string field values containing single quote chatacters, handling maximum text field lengths, date field formatting for queries and inserts, verifying numeric field values, recovery from null field errors, etc.

* Resolves many of the subtle issues related to differences between various SQL systems (MySQL, Oracle, Access, Postgres, etc.)

* Allows you to define constants for database field values in the flow of the SQL schema, and will automatically create enumerations for use in the application.

* Provides a very easy-to-use programming interface to the SQL system.  

The logic handles many database programming situations such as multiple database connections, multiple table buffers, using SQL DML v.s. recordset operations, defining the system to generate only the desired type of access for each table, etc.  The generated code can also be used for VBA applications.

This system has been in operation for a number of years, and therefore is very solid and well-tested.  Full documentation in the file Documentation.doc, and a sample app is also included.