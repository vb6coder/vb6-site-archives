==========================================================================
CREATED BY:	MUHAMMAD HARIS NISAR
==========================================================================

How to Format text:

1. Launch ExtFrmtUnd.exe.
2. Type some text in Rich TextBox.
3. Select some of the text you've written.
4. Click on 'Format Menu'.
5. Select your favorite formatting.
6. Now formatting has been done.
7. Enjoy!


===========================================================================
You can e-mail me at:
	true_innocent_hero@yahoo.com
===========================================================================