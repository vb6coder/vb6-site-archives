This is a Tutorial for an RPG game it�s not much but it shows you how to make you character walk without the flickering images and without using bitblt or DirectX. The code is simple and easy to understand.

This Tutorial also shows you how to set Boundaries so you character does not walk off the screen or walk into objects such as the trees or any object you wish to add on.

I have also included in this tutorial how to make your character talk to other characters in the game. The point of this is so when you wish to make an RPG or an adventure game you have a real story line.

Feel free to use and experiment with this however you wish to and please email me to either give feedback or if you wish to make a full 2D RPG/ adventure game.

Email Holland795@hotmail.com
MSN = Holland795@hotmail.com
Yahoo = svaughan28@yahoo.com

Thanx
