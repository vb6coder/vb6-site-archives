Excellent Fire Effect with burning text!

I have seen many fire effect but this is not a simple fire effect. have you ever seen a burning text i think you have never seen such effect alone and with text.Fire inside text,fire on top of text and a picture is worth of thousand of words just see the picture and feel the power of vb in graphics