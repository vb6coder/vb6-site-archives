/* Msg.java
This program defines how a message sent from node to node should look like.

28-Jan-1998: created by Thomas Prokosch (tp)
31-Jan-1998: changed implementation for source and destination addresses (tp)
*/

import daj.Message;

public class Msg extends Message {
    public int type=-1, data;
    protected int src, dst;
    static final int INQUIRE=1, REQUEST=2, RELEASE=3, RELINQUISH=4, ACK=5;

    public Msg(int s, int d, int typ, int dta) {
        src=s; dst=d; type=typ; data=dta;
    }

    public Msg(Msg old) {
        src=old.src; dst=old.dst; type=old.type; data=old.data;
    }

    public Msg setdest(int d) {
        dst=d;
        return(this);
    }

    public String getText() {
        switch (type) {
        case INQUIRE:  return(new String(data+": inquire ("+src+"-"+dst+")"));
        case REQUEST:  return(new String(data+": request ("+src+"-"+dst+")"));
        case RELEASE:  return(new String("release ("+src+"-"+dst+")"));
        case RELINQUISH: return(new String("relinquish ("+src+"-"+dst+")"));
        case ACK:      return(new String("ack "+(data==0?"neg":"pos")+
                         "("+src+"-"+dst+")"));
        }
        return(new String("message type not known"));
    }
}
