/* mutex.java
This program implements Maekawa's voting algorithm for mutual exclusion
as described in R. Chow et al, "Distributed Operating Systems & Algorithms".

26-Jan-1999: created by Thomas Prokosch (tp) based on
             Christian Mittermaier's (cm) formalized model
31-Jan-1999: changed voting district
*/

import daj.*;
import Prog;
import java.lang.Math;

public class mutex extends Application {
    Node proc[];
    static final int SQPROCS=4;        /* square root of the number of procs */
    static final int NOPROCS=SQPROCS*SQPROCS;

    /* starter of program when run as an applet */
    public static void main(String[] args) {
        new mutex().run();
    }

    /* starter of program when run as an application */
    public mutex() {
        super("Maekawa's Voting Algorithm", 400, 400);
        proc=new Node[NOPROCS];
    }

    /* construct creates the nodes and the links between them randomly */
    public void construct() {
        int i, j;
        setChannelWidth(2);

        /* create the processors */
        for (i=0; i<NOPROCS; i++) {
            /* place the procs on the screen */
            proc[i]=node(new Prog(i, SQPROCS), String.valueOf(i),
               80*(i%SQPROCS)+80, 80*(i/SQPROCS)+80);
        }
        
        /* create links between the given processors */
        for (i=0; i<NOPROCS-1; i++) {
            if (i<NOPROCS-SQPROCS) {   /* link vertically */
                link(proc[i], proc[i+SQPROCS]);
                link(proc[i+SQPROCS], proc[i]);
            }
            if (i%SQPROCS<SQPROCS-1) { /* link horizontally */
                link(proc[i], proc[i+1]);
                link(proc[i+1], proc[i]);
            }
        }
    }

    public String getText() {
        return "Maekawa's Voting Algorithm\n\n" +
            "This program implements Maekawa's\n"+
            "voting algorithm. With the help of\n"+
            "this algorithm, an application may\n"+
            "enter a critical region.";
    }
}
