Title: A   Text Encrypter/Decrypter
Description: This application can take any text (typed in or an opened .txt or .rtf file that is no more than 4000 chars) and encrypt it with a password. The password is used in the encryption, so only the correct one will correctly decrypt the text. This program also demonstrates the use of a progress bar and the opening and saving of text files.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=50192&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
