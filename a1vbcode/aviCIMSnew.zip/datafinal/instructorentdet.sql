create table instructor(
inst_id number(5) primary key,
first varchar2(10),
last varchar2(10),
gender varchar2(1),
addres varchar2(30),
city varchar2(10),
phone number(10),
quali varchar2(10),
f_name varchar2(20),
date_join date);

commit;
insert into instructor values(1,'ravi','gupta','m','gomti nagar','lucknow',0786,'m.tech','arun','27-apr-2008');
commit;