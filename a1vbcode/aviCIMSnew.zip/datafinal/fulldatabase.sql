drop table student;
drop table course;
drop table users;
drop table instructor;
drop table transaction;
drop table acc_head;

create table acc_head(
head_id number(5) primary key,
head_name varchar2(10),
type varchar2(30));

commit;
insert into acc_head values(1,'duggal','accountant');
commit;



create table transaction(
student_id number(5) primary key,
pay_date date,
paid_amount number(5),
description varchar2(30),
bill_no number(5)); 

commit;
insert into transaction values(1,'28-apr-2009',5000,'.net package',1);
commit;



create table course(
course_id number(5) primary key,
course_name varchar2(10),
fees number(5),
duration number(2));
commit;
insert into course values(1,'.net',5000,2);
commit;



create table instructor(
inst_id number(5) primary key,
first varchar2(10),
last varchar2(10),
gender varchar2(1),
addres varchar2(30),
city varchar2(10),
phone number(10),
quali varchar2(10),
f_name varchar2(20),
date_join date);

commit;
insert into instructor values(1,'ravi','gupta','m','gomti nagar','lucknow',0786,'m.tech','arun','27-apr-2008');
commit;



create table student(
stu_id number(5) primary key,
first varchar2(10),
last varchar2(10),
gender varchar2(1),
address varchar2(30),
city varchar2(10),
phone number(10),
quali varchar2(10),
f_name varchar2(20),
date_join date);

commit;
insert into student values(1,'mubin','ahmad','m','indira nagar','lucknow',4209211,'b.tech','mohd.alim','27-apr-2009');
commit;



create table users(
username varchar2(10) primary key,
pass varchar2(10));

commit;
insert into users values('420','9211');
commit;

commit;