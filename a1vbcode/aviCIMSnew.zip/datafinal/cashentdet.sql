create table transaction(
student_id number(5) primary key,
pay_date date,
paid_amount number(5),
description varchar2(30),
bill_no number(5)); 

commit;
insert into transaction values(1,'28-apr-2009',5000,'.net package',1);
commit;