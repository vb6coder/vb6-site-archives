create table acc_head(
head_id number(5) primary key,
head_name varchar2(10),
type varchar2(30));

commit;
insert into acc_head values(1,'duggal','accountant');
commit;
