create table users(
username varchar2(10) primary key,
pass varchar2(10));

commit;
insert into users values('420','9211');
commit;