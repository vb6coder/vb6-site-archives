create table student(
stu_id number(5) primary key,
first varchar2(10),
last varchar2(10),
gender varchar2(1),
address varchar2(30),
city varchar2(10),
phone number(10),
quali varchar2(10),
f_name varchar2(20),
date_join date);

commit;
insert into student values(1,'mubin','ahmad','m','indira nagar','lucknow',4209211,'b.tech','mohd.alim','27-apr-2009');
commit;