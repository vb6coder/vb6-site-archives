create table course(
course_id number(5) primary key,
course_name varchar2(10),
fees number(5),
duration number(2));
commit;
insert into course values(1,'.net',5000,2);
commit;