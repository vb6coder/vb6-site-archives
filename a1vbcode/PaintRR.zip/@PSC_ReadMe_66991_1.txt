Title: PaintRR(Update 02Sep09)
Description: PaintRR by Robert Rayment. (Update 02 Sep 2009: See below) This painting program puts together a lot of the things I've done separately before but with changes; true color, additions &amp; improvements (hopefully). Too many things to describe here - so a list. 20 Main menu items, over 250 Drawing tools (arranged in 19 Tool groups), 33 Filters, 35 Deformers, 32 Extras, 6 Textures with variations and animation, Print Preview, Image merging, Draw mode, Zoom mode, Trace mode, Clipboard functions, bmp, jpeg, gif, png &amp; tif saving, picture drop onto exe, ini file for recent files, form locations, saved colors and color scheme etc, etc. Relatively easy to add further Tools, but had to stop somewhere! Important to read the on-screen help. In particular the drawing method and running in the IDE with a clipped mouse and break points. If you don't COMPILE this program you'll not see the benefit! Only fully tested on WinXP. Acknowledgements in the help file. I enjoyed writing this and hope you at least find it entertaining:)  NOTE: If the chm help file, paintrr.chm, does not work then open it on it's own and uncheck the security button.
__________________________________________________
Update 2 Sep 2009: Adjustment for back spillage when half-toning.
__________________________________________________
Update 31 Aug 2009: Added HalfTone menu, see screenshot. Zip 1.7MB.
__________________________________________________
Update 9 July 2009:...1. Some adjustments for 120dpi...2. Color menu enhanced slightly see Update.txt
__________________________________________________
Update 4 July 2009:...1. Re-arranged side menus' appearance and added retractable covers for top buttons...2. Added drag-drop images onto drawing canvas. Zip 1.67 MB.
__________________________________________________
Update 27 June 2009:..1. Added gradient, filled &amp; random filled to Text options. Also allow ClearType for angled text... 2. See Updates.txt for other changes and corrections.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66991&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
