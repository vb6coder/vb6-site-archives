Title: Grading System - Template
Description: It is a system based that used to rate students.although it is the backend is MSACCESS it can be converted to MSSQL.. this system is a sample any comments and suggestion please post it... i'm online in rent a coder
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=65763&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
