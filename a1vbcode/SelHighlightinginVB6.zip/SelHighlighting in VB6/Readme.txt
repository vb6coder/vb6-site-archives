==========================================================================
CREATED BY:	MUHAMMAD HARIS NISAR
==========================================================================

How to make formatting:

1. Launch SelHighlight.exe.
2. Type some text in RichTextBox Window.
3. Select some of the text that you've written.
4. Right Click on it from your mouse.
5. Click on 'Hightlight Text'.
6. Choose color for highlighting and then click on 'OK'.
7. Done, the selected text has been highlighted.


===========================================================================
You can e-mail me at:
	true_innocent_hero@yahoo.com
===========================================================================