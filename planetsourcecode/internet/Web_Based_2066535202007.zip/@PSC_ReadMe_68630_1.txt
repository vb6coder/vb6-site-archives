Title: Web Based Auto-Updater
Description: This code is a working (that i know of) Auto-Updater that uses the INet Control to connect to a webserver to update the files. Im currently using it in my project and its working beutifuly. The code is also EXTREAMLY Commented, i did this before submitting it. This is my first submission to psc so post comment if you have any problems.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=68630&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
