.:AUTO-UPDATER By EMBLEM:.
When editing the source there are a fiew things you need to do.
Search for "TODO:" to find them.

There are two projects in this zip file, one is the Auto-Updater.
The other is a Compression/Decompression Wizard.

The Compression.bas i got from another project on PSC, please email me
the-emblem@hotmail.com if you make it and ill at credit where its due.

IF you use this project in any other big projects, please give me some credit.
Its not required but Id love to see my name spread around the internet.

Thanks alot and have fun with this auto updater!

Credit:
  Emblem for Creating it.
  Topher for testing it.
  The person who created the Compression.bas