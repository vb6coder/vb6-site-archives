A DX7 MultiPlayer Tic Tac Toe 
                 Submitted on: 10/10/99
                 By: Mike Altmanshofer 
                 Category: VB 5.0/6.0
                 Users have accessed this code 456 times. 

   This is an example of using DX7 DirectPlay4. Program allows you to connect and play a
   basic tic tac toe game over ipx, tcp/ip, or modem against another player with the same
   program installed. This program includes a basic chat program. All of the multiplayer code
   is done with directplay4. This is a multiplayer tic tac toe game i originally wrote using the
   com port across a modem. I recently ported it to directplay4 just for the fun of it thought
   the code might be helpful. Requires DIRECTX7 SDK to compile and DIRECTX7
   runtime to play. 