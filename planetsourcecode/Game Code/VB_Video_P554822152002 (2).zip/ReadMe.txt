Hi everybody...

Couple days ago I downloaded poker game from CNET. (I like poker:)))).
It was shareware. Interface was ugly, and program send me registering messages  every 10-15 seconds even if trial period still didn't expired! That really pissed me off...

So I decided to write game on my on. And here it is. Let me know if you find any bugs (I did not tested all if-then blocks)...

P.S.

I'm now trying to add more options (with jolly card) but when I finished programming and tryed to run I get the message "Procedure too large". So if anyone knows how to make procedure short please email me.

kdalibor@ptt.yu

C Ya...