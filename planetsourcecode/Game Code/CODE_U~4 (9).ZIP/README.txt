Ok, this one should have everything and should work... but
ya never know. This game is hardly finished and feel free to do
 whatever to it, i dont care ( i think i gave the rights to planet
source code anyways) . anyways i hope you enjoy this , it took me a long time
and if you have any complaints, ideas,coments, or just wanna drop a line
send all email to   

mikesullins@diplomats.com


thanks