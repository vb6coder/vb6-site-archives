	      
	           * * * * * * * * * * *

       	           C O L U M N S   1 . 0 

	           * * * * * * * * * * * 



			 *   *   *



Folders:
    
    Ensure that all files have been extracted in correct folders:

    ['Application Folder']
        <Project files>
        [Wavs]
	    <*.WAV>

Scoring:

    See splash screen instructions.

Difficulty:

    One level up increases speed (Until level 20 / Every 15000 points).

High-Scores:

    To reset High-Scores table, delete HighScores.dat file.


			 *   *   *


		     Carles P.V. 2001
	            carles_pv@terra.es

                             ;)