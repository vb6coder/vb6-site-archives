	      
	           * * * * * * * * * * *

       	             C O L U M N S  II

	           * * * * * * * * * * * 

		    Two players version		

			 *   *   *



Folders:
    
    Ensure that all files have been extracted in correct folders:

    ['Application Folder']
        <Project files>
        [Sound]
	    <*.WAV>
	    <Theme.MID>		

Quick keys:

    Main screen:

    [Return]: Start game
    [Esc]:    Exit Columns II
	
    [P]:      1/2 Players
    [I]:      Instructions
    [H]:      High-Scores 

    [T]:      Background theme [Y/N]

Game keys:

    See instructions.

Scoring:

    See instructions.

Difficulty:

    See instructions.

High-Scores:

    To reset High-Scores table, delete HighScores.dat file.


			 *   *   *


		     Carles P.V. 2001
	            carles_pv@terra.es

                             ;)