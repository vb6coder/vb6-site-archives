This was actually created in the summer of 2000, but I have recently made 
some chages to the rules.  I was unaware that on your second+ yahtzee you get a
bonus as well as get to choose any location on the bottom of the score card.  
I used to give the bonus, but only allow them to choose 3 of a kind, 4 of a kind, 
chance, or the respective slot on the upper section of the score card(eg, ones, twos, ect..)
Anyways, that is fixed as well as a registry bug.. So enjoy