Title: MvQuiz with Animation
Description: This program is a motor vehicle quiz using the Microsoft Agents. Its a series of motor vehicle questions for the students to learn. But the questions and answers can be adapted to anything you wish. You can also choose any Text to Speech engine installed on your computer.
If you like and use this code please give it a vote.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=40194&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
