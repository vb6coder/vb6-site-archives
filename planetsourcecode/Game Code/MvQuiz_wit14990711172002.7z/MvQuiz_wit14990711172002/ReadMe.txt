MvQuiz with Animation

This is a program I made 7 years ago with VB4-16 bit and now VB5 for the
college where I work. But I have updated it to included the Microsoft
Agents. Its a series of motor vehicle questions for the students to learn.
But the questions can be adapted to anything you wish.

You can also choose any Text to Speech use any language installed on your
computer.

It uses Microsoft Agents which can be downloaded from:

http://www.microsoft.com/msagent/

If you are using Windows 95\98 then you need to download and
install msagent.exe.

MS Characters - merlin.exe, genie,exe, peedy.exe and robby.exe can also be
downloaded from the same site.

If you are using Windows 2000\ME\XP then they may already been installed
in [Windows Folder]\Msagents\Chars.

To make the program run you only need to download and install msagent.exe
and merlin.exe. The program checks to see if the other agents are
installed before loading.

The program saves Date, Time and Score in a Results.dat file for reference.

It only took a day to modify, so there maybe some bugs in the program. But
it works perfectly on my Windows 98. If you find any bugs or improvements
then please e-mail me at:

Keith.Stanier@BTinternet.com



I have the following programs already installed. But you may need to
download and install:

1) Microsoft Agent core components (395k), msagent.exe
 
2) One of the TTS3000 text-to-speech engines (around 2mb each).You can
download as many engines as you like here. The more you get, the more
"accents" you will have. I personally have the "British", "American", 
"French", "Italian", "Portugese", "Russian", "Japanese", "Spanish",
"German", "Korean" and "Dutch" versions.

3) Then download the Microsoft SPIA 4.0a runtime binaries (824k)
from http://www.microsoft.com/products/msagent/downloads.htm#sapi

4) Lastly, download the Speech Control Panel (927k)
from http://www.microsoft.com/products/msagent/downloads.htm
