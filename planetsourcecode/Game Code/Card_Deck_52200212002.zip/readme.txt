************************************************************************
			CARD DECK CONTROL v1.0
			    BY RALPH TODD
************************************************************************

This control displays card images. It takes all the card images from one
image and just chooses the one that you need. The pack contains 52 normal
cards and 13 various card backs. 

Below are explained some of the unique events/properties/methods included

METHODS
About - Displays the about form
GetSuit - Returns the suit of the current card in number (1=diamonds, 2=clubs,
	  3=hearts, 4=spades)
GetSuitString- Returns suit of current card in words (eg "Spades")
GetValue - Returns Value of the current card in number
GetValueString - Returns Value of current card in words (eg "Ace", "Five")
NextCard - Shows the next random card. (The cards are shuffled so you 
	   actually wont see the same card again until the end of the 
	   pack. You can shuffle with the shuffle method
SelectCard - Selects card, as if you clicked it
ShowBack - Shows a different back
ShowImage - Just shows the image of the current card number
Shuffle - Shuffles the cards (use it with the nextcard method)

PROPERTIES
borderwidth = width of the border shown on mouseover/click/focus
colorclick = color of border around the card when you click it
colorfocus = color of border when it has focus(toggled with ShowFocusRect)
colorover = color of border when the mouseover(toggled with ShowMouseOver)
CurCard = Current Card shown (or to be shown)
MouseIcon/MousePointer = can display a special mouse icon
ShowFocusRect/ShowMouseOver = toggles respective boxes drawn

EVENTS
All normal ones (click,dblClick, etc) included
Shuffled - When cards have been shuffled
MouseOver/MouseOut - When mouse goes over and out


Images from Championship Euchre game

Email me at doddsie007@hotmail.com
		