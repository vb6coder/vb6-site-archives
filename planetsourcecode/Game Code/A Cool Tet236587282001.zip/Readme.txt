Tetris - By Rosh Mendis
=======================

A simple yet so addictive game played and enjoyed by many. Includes two player options so you can play against a friend as well, nine levels, a level editor and a high scores list. This software is freeware so feel free to distribute.

Controls
--------
One player uses the arrows and enter to drop the blocks to the bottom
The other player uses w (up), s (down), a (left), d (right), q (drop)
To make the blocks drop as fast as the computer lets you press Crtl+Z.

Using the Level Editor
----------------------
There are two ways to open the level editor. You can either go into the project file and change the startup form to frmLevelEditor, or during a one player game press Ctrl+X. Saving a level normally just saves the position of the blocks. But if you want to play the level you must use the Save Code option and copy the contents of the file into the New_Game subroutine where you will find all of the other levels. I just thought it wasn't a good idea for the player to be mucking around with the levels.

Contact
-------
Send any comments, criticism, about the game or its bugs to me at

		roshmendis@bigpond.com

Sites
-----
Here are some vb programming sites I recomend you vist :
http://www.vbgames.co.uk/index.htm		- Great directx stuff
http://rookscape.com/vbgaming/tutorials.php	- Awesome tutorials
http://www.acky.net/vb/				- Games+graphics examples
http://www.vbgames.com/				- Good example vb games