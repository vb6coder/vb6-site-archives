10:51 AM 5/20/01
Hacker RPG v 0.02a4 -------------------- By TECHNO

This readme is in 5 parts:

1. Known Bugs
2. Revisions to this version
3. Compatability
4. Work progress
5. Contact / help with the project


1--------------Known Bugs----------------

A) Under windows ME, some soundcards dont play
   sounds??
B) Stack errors
C) Slow Animations/Lag
D) Unexpexted Quits

(note: Bugs B and C are fixed as of this version)

2--------------New features--------------

A) Menu implemented (improved)
B) Menu Animations
C) More menu options!
D) Major Improvements on walking controls
E) Added more graphics

3--------------Compatability-------------

Some Operating systems I tested on (please send your results)

Windows 95B:      Control problems
Windows 98:       Works
Windows 98SE:     Works, minor bugs
Windows ME:       Works, minor sound bugs
Windows 2k pro:   Works, No Bugs
Windows XP:       ???

4--------------Work Progress-------------

Game percent completed (estimated)  0.60%
Game development hours:  10

5--------------Contact/help--------------

Email: Techno@phreaker.net
AIM:   TecDanc
Web:   http://hackerrpg.homestead.com
web2:  http://www.dvdtoolz.com


HELP!!

If you are good with 3d studio max, or any other 3d program,
we are looking for talented people to help us with the 
pre-rendered backgrounds! and or character design! please
if you are interested, contact me

