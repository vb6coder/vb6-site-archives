Sorry if you had this problem:
the background was not properly set in the INI file, and you had
to erase the INI file so that the program could create a clean
default one to work :(

Please, note that this project is far from finished (see WIP.txt for
main issues and "to do" list).

Keys can't be redefined, and the defaults are:
numPad 4 : left
numPad 6 : right
numPad 8 : speed block down
numPad 5 : rotate block clockwise
numPad 8 : rotate block counter-clockwise

All others parameters and high scores are properly handled,
save in the INI file, and read back ok.

I'll take advantage of the opportunity to add this:

What is good about THIS code compared to other Tetris source codes is
that it uses heavily APIs. I wanted to make a Tetris available to
everybody that uses PROPER gaming techniques! I've seen to many Tetris
clones around there using timers, KeyPress event, and worse... PICTURE
BOXES to display the box! Yuck :) I felt very sorry. This code is far
from perfect and is not finiched, but as a start, it is much better in
my opinion. Here are the APIs I used:

* Graphics are stored in memory (no PictureBox whatsoever) with hDCs.
* All graphics manipulation are done using sprites and a backbuffer
(using BitBlt and other APIs).
* No timers, only GetTickCount APIs
* No Keyxxxx event, but GetKeyState API
* No MCI control, but mciSendString API
* No Common Dialog control, but GetOpenFileName API.
* No Label controls, but TextOut API.
* Settings saved in .INI file using specific APIS agin :)

I did not use registry because it is not clean in my opinion (leaves
traces when removing the software).
If you like the main form, you will notice it doesn't contain ANY
control :) Just a form with a menu :)

Also, I implemented some parameters that I did not find in any other
Tetris before. For instance, level changing can be fully cusomised.
You can also play with normal plain blocks, random plain blocks, and
random blocks (you've got to try it to understand what I mean) :)

Hope you like it as it is, and hope that it is useful to some of you
too! If people like this program, I have some more to submit, like a
two-players Columns with several original graphics templates :)

Cheers! Enjoy! Bye now! :)