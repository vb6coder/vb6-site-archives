Hello!
Thanks for downloading this code.
As you know, this was written from scratch by me and is made for my future RPGs.
So if you're gonna use any part of this code, including graphics, contact me first.

E-mail: dudeup2000@yahoo.com


Furthermore, enjoy!