Title: Naby RubiksCube
Description: i like to play RubiksCube i found a great 1 in that site about it i realy i donot remember the creator name i use his user controll of him and make some change i add Rotate Cube and The Color Of Hidden Faces Shown i hope u like it have fun
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=71756&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
