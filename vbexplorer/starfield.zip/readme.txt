This example prepared by Theodore's Visual Basic site; you can visit his site at http://www.forthnet.gr/ionikh/home.htm . 



Comments added by Burt Abreu at Visual Basic Explorer, http://www.vbexplorer.com .