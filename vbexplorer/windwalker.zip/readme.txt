What is WindWalker? 

WindWalker was the beginning of a game that Soren Christensen and I were working on as part of a book idea we had. Soren provided almost all of the programming you see. I essentially developed the game idea and created the background tiles and provided the technical reviewing, game design and some art and sounds. There is also an overhead view sprite that was created by Hermann Hillmann. 

The project began to get more and more involved and was going in a direction that would have made it unsuitable for a beginner's book. We ended up working on other material and now it seems that because of our schedules we may not be able to get back to this. Rather than let it go to waste we decided to release it on the web site in the hopes that you will be able to learn from it and use it in your own games. There are also several sample chapters which are in various states of completion which I plan on converting to HTML soon and posting. The sample chapters were the first three from the book and so don't really touch directly on the WindWalker project which was to be one of three final games built in the book. It was intended to be a Space Invaders� scrolling type game but I wanted to use a different theme to add some interest and we hoped to add some functionality that was aimed at teaching specific concepts. 

This project, and the tutorials when they are ready, may not be reposted or distributed without my written permission. This is simply because at some point we may decide to use some of the the material, or if we make changes, additions or corrections we won't have bug ridden copies scattered around the net (the tutorials may also have some minor errors as these were still draft copies). You may use this code in any projects commercial or otherwise however you wish. We would appreciate a brief mention if you find the code particularly helpful -though it is not required. If you want to comment on the code or have questions please ask them through the VB Forums page as it is unlikely that we can support this -especially since one of the reasons we dropped it was our lack of time. 

If you make improvements or add significant functionality, and want to release the code, I'll be glad to post it here for all to learn from. If you are an artist and want to create other levels like the first 4 tiles I did (probably better than my humble efforts ;-) I may be able to post them here in case someone wants to try adding additional levels. I do have several versions of this, some with beginning AI implemented and some additional class modules and after I review them with Soren I may post them here for you to experiment with. 

Please let us know if you find this useful as it would be a thrill for us to know that somebody actually built something using it, inspite of the fact that it is incomplete. The sample is in VB6 since that is what I am using. The code also works in VB5 and I am looking for a tip I had seen on converting VB6 to VB5. I'll do that ASAP so that more of you can use it. 



The sound is implemented using a control that Soren created which wraps some of the DirectX API. This allows for better sound play as well as playing of simultaneous sounds. The EasySound control is available on the Visual Basic Explorer ToolBox page. 


Burt Abreu
Soren Christensen
http://www.vbexplorer.com

