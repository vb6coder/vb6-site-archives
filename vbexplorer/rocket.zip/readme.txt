		Rocket Blast Off
Version 1.4.0
Written with VB4-32 - Win95 compatible
		    - It may run in Win 3x

(use word wrap for ease of reading)

Ham & Ham Services
Ed Hammond
hamham@harborside.com

Uddip Mitra, indioman@hotmail.com, taught me how to make the mouseup function work.
******************************************************* 
See PROGRAM OPERATION below for questions on how to use the program.
******************************************************* 

		Program History

This is something I originally made in VB 3 class. I used command button click events to make the rocket move. Now it uses mousedown and mouseup events to scroll the rocket. The program also uses the Select Case function instead of If statements to select the direction of movement.

Uddip taught me to use the DoEvents statement to pause a loop and check for other events to be processed. Specifically the MouseUp event in this case. Before each loop is completed it checks for the MouseUp event using the DoEvents statement. 

I have included both the source code and the exe program in this zip file. If you use the exe file you will have to create your own shortcut as there is no setup program. If you use the code in another program please let me know. If you make improvements to this please send me a copy of the code.

******************************************************* 

		PROGRAM OPERATION

		Rocket Blast Off

This is a simple program to show how to use the MouseDown and MouseUp events. 


- Left Button
If you push down the left mouse button, on the Left Button the rocket will scroll from right to left on the form. When the rocket reaches the left side of the form it will disappear and reappear on the right side of the form. This scrolling action will continue until the left mouse button is released.

- Right Button
If you push down the left mouse button, on the Right Button the rocket will scroll from left to right on the form. When the rocket reaches the right side of the form it will disappear and reappear on the left side of the form. This scrolling action will continue until the left mouse button is released.

- Up Button
If you push down the left mouse button, on the Up Button the rocket will scroll from down to up on the form. When the rocket reaches the top of the form it will disappear and reappear on the bottom of the form. This scrolling action will continue until the left mouse button is released.

- Down Button
If you push down the left mouse button, on the Down Button the rocket will scroll from top to bottom on the form. When the rocket reaches the bottom of the form it will disappear and reappear at the top of the form. This scrolling action will continue until the left mouse button is released.

- Exit Button
This menu option will end the program.

- Help Button
This Button will run this file (readme.txt). When Help is selected a message box will open and ask "Do you wish to read the program instructions?". It has two buttons, Yes and No. One of these buttons must be selected.

- Yes Button
The yes button will open the "readme.txt file that contains instructions on how to use the program and a history of this program.

- No Button
The no button will close the message box and display the form the way it was before Help was selected.

*******************************************************			    End of File
*******************************************************