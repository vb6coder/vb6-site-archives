
COUNT DOWN ALARM TIMER
Version 1.2.0
Ham & Ham Services
Ed Hammond
hamham@harborside.com

Modified by Uddip Mitra
Interstellar Software Cell
indioman@hotmail.com

Written with VB4-16
Should be Win31 or Win95 compatible
******************************************************* 
Check out this modified code. There is no flicker, and the timer code is shorter. This new code uses TimeSerial and DateAdd functions to change the time instead of nested If statements. It is more efficient and solves the problem of maximum numbers.

Important notes from Uddip Mitra:


The function TimeSerial(h,m,s) takes three parameters - Hours, Minutes and Seconds. It returns the value in "Time" format which is equivalent to "Date" format. i.e. TimeSerial("15","20","20") returns 15:20:20 which can be used to set the current computer system time.

Read the following line in your procedure "Private Sub Mydisplay()": Label1.Caption = Format$(Time, "hh") & ":" & Format$(Time, "nn") & ":" & Format$(Time, "ss")
This line is the one which converts the value stored in the variable "Time" to a string which is fed to the Label1 caption.

The funtion DateAdd(interval, value, date): This function takes three parameters 

- interval (specifies the part of date that is to be operated on i.e.Day or Month or Year or Hour or Minute or Second), 

- value (specifies the amount of addition to the part of the date that was selected in "interval") Here you can have a negative number to subtract and a positive number to add.

- date (specifies the Time or Date to which you want to make modifications)

DateAdd Examples: 
DateAdd("m", 2,"21 Jan 1998") will return "21 Mar 1998"
DateAdd("m", -2,"21 Jan 1998") will return "21 Nov 1997"
DateAdd("yyyy", 3,"21 Jan 1998") will return "21 Jan 2001"
DateAdd("yyyy", -3,"21 Jan 1998") will return "21 Jan 1995"

There was also one important thing I should mention here: the variable you declared "Dim Time ..." should not be used as a programming habit because "Time" itself is a Visual Basic reserved keyword. Instead use "dTime" or "sTime" which means you add some prefix to denote the type of variable.
******************************************************* 

This is something I threw together in one day in response to the question below from Visual Basic Explorer - Message Board. It is not a top notch program but it is functional. It has a flicker in the the time remaining display I could not figure out why. (*** Fixed *** It will also only run a maximum of 08:59:60. If set higher a GPF occurs. *** ) Burt over at Visual Basic Explorer Provided the answer. I was using Integer type for Hours and Time variables when the type needed to be Long. Thanks Burt.

I have included both the source code and the exe program in this zip file. If you use the exe file you will have to create your own shortcut as there is no setup program. If you use the code in another program please let me know. If you make improvements to this please send me a copy of the code.

It is a simple count down program. Enter the hours, minutes, and seconds to get the total count down time. Click the start button and the time starts to count down. When the time remaining reaches 0 a beep will be heard and the reset button will be enabled.

The pause button is to temporarily stop the timer and enable the reset button. You can restart the countdown by clicking the start button and the program will continue as if it were not paused. Or reset the time by clicking
the reset button and entering new hours, minutes, and seconds.

This program will run minimized so you can be doing other work while it is running. I tried it with some programs and some screen savers and had no problems. If you find any let me know.
******************************************************* 
A SIMPLE COUNTDOWN PROGRAM
Tuesday, 09-Dec-97 00:45:48

Message:

Hi, i know i have posted in this before, but once again I have an important question to ask. I started a count-down program for my sister because she was not using her time wisely on the pc ';-) In the program, I want it so that you select a value, say , "30 minutes" from a list box and then on the form you have a start and stop command button. All I want is that when you select a number, again say "10 minutes", is puts 10:00 in another list box and starts counting down, 9:59, 9:58, 9:57, etc.. And if they pick "10 seconds", it should say, "00:10, 00:09, 00:08, 00:07, etc.

IF ANYBODY HAS ANY IDEA ON HOW THEY CAN HELP PLEASE RESPOND!

Thanks,
