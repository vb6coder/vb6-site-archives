Date:  July 25, 1999
File:  Final-Source.zip

Contents:
---------
These file are the project's source code and sound files.

NOTES:
-----
You'll also need the Final-Graphics.zip & Final-Help.zip files - they should be located in the same place as where you found _this_ file :-)

Soren Christensen's EasySound(tm) control must already be installed to run this project.  You can find this control at: www.vbexplorer.com/files/ss.zip  You can read about EasySound(tm) at: www.vbexplorer.com/sound.asp