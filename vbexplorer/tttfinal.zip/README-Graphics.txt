Date:  July 25, 1999
File:  Final-Graphics.zip

Contents:
---------
These file are the graphics used by the project.  These files _must_ be loaded into the same directory as the source code.

NOTES:
-----
These files _MUST_ be extracted to the same folder as the source code files (found in the file Final-Source.zip).