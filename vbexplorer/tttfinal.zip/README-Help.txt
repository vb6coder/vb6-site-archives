Date:  July 25, 1999
File:  Final-Help.zip

Contents:
---------
These file are used to develop the project's Help file.

NOTES:
-----
These files _MUST_ be extracted to a sub-folder named "Help".  That is to say, if the source code (located in Final-Source.zip) is saved to a folder "C:\TTT", then these files must be located in "C:\TTT\Help".