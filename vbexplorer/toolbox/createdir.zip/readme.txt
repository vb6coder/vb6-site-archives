Hi if you got here you must care enough to at leaet try it. :)
Open a new project and add these files to it.

UI.frm - demo form to demonstrate the CreateDir function
IO.bas - contains the CreateDir function

Created: VB 4.0
Tested in VB 4.0, 5.0, 6.0

Enjoy,

Rick Dormer - rickmis@bellsouth.net


