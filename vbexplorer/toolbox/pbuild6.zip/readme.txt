This is the revised procedure builder template for VB6

To use it load the project into VB6 and run AddToINI from the immediate window. This adds info to VBADDINI.INI. It also writes to the registry the Author and Organisation details (mine initially but these can be changed). Then compile the project and it should be available to Add-In Manager. Select Procedure Builder and set its load behavour to loaded from Add-in Manager which will make it available from the Add-Ins Menu.

It has new facilities over the VB 5 version including ...

Ability to include friend functions/subroutines
Error template uses err.raise in class modules rather than a message box
Can add comment and/or error template to an existing procedure or function. It also now works
with property get/let/sets.
I've replaced the rather cludgy listboxes for parameter input with a list view control.

I've tested it as much as possible but if there are any problems let me know and I will attempt to fix them... or since you have the source code you can fix it yourself...

I would appreciate any feedback.

I use it and I find it useful - hope you do the same..

Cheers

Mark Kirkland
mark.kirkland@brighton-healthcare.com