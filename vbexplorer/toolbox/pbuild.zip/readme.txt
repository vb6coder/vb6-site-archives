This is a procedure builder template for VB5 that I wrote because I couldn't find anything 
that did the same thing (this isn't to say that such an add-in doesn't exist). It is free, 
so play about with is as much as you like.

To use it load the project into VB5 and run AddToINI from the immediate window. This adds
info to VBADDINI.INI. It also writes to the registry the Author and Organisation details 
(mine initially but these can be changed). Then compile the project and it should be available
to Add-In Manager. Select Procedure Builder from Add-in Manager which will make it available 
from the Add-Ins Menu.

I would appreciate any feedback.

I use it and I find it useful - hope you do the same..

Mark Kirkland
mark.kirkland@brighton-healthcare.com