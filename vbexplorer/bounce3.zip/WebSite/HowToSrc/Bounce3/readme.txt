http://www.vb-helper.com/HowTo/bounce3.zip

	Purpose
Animate a complex moving object.

	Method
Use the BitBlt API function.

	Disclaimer
This example program is provided "as is" with no warranty of any kind. It is
intended for demonstration purposes only. In particular, it does no error
handling. You can use the example in any form, but please mention
www.vb-helper.com.
