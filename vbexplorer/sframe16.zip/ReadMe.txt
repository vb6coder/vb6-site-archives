
        *********** SFrame16.vbp **************

              Ed Hammond
              hamham@harborside.com

This is part of an Invoice program I wrote a few years
ago in VB4-16. You can use all or part of this program
if you can. """ Please Email me if you use it for other
than personal use. I would like to know !!! """

I have reduced the contents of the program to mainly
show the method of scrolling a frame on a form.

I think the code is documented fairly well. I hope this
will help somebody.

I think this site for VB programers by VB programers is
great and a good idea. I would like to ask everybody to
download and upload something.

Thanks,

Ed
  