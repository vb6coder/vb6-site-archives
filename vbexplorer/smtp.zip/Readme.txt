SMTP: Simple Mail Testing Program

Legal: I am not responsible for anything to do with this program, source code, or anything
about it!! You use it at your own risk!! But on the good side.. it's source code so you
can see what it does!!

Credits: Craig Gill?? I believe he is the one that wrote the original semi-working code
sample that I got, modified and made work. Thanks Craig (if that's who put up the code)
for helping shove me in the right direction here!!

Use: The sample here was written/compiled using VB 5.0 Enterprise Edition SP3, it SHOULD
work in any version of VB (you may need to cut and paste the code), but I have only used
it in the above environment.


The code is actually pretty simple, it simply uses windows own Winsock to send e-mail via
SMTP. It makes a connection via TCP on port 25 (If you don't understand what TCP and port
25 is, you may consider brushing up on TCP/IP before using this, but it is not a requirement)
and sends basically text to the SMTP mail server. This is what SMTP stands for SIMPLE Mail
Transport Protocol.  I have tried as much as possible to self document the code, so I will
not got into details here. Just look through it and see what you can do. 

Side effects: Well heck this is really a small simple little E-Mail program good for sending
e-mail to any SMTP mail server. As long as the PC has the VB5 runtimes & Winsock loaded this
should work with out any install programs. So it might be a handy tool to have. Because the
scary part is with Wise 5.0 install this thing GROWS to 1.3MB (About 300-400K smaller than
the built in VB5 setup program maker).

What's next with this?? Well I may make it into an ActiveX control for VB/C++ programmers 
that need an quick easy and FREE way to send e-mail from their programs. But we'll see.

Questions, comments, Death threats, Marriage proposals: brian@worldcomputers.com

-Brian Anderson
