Open Face off V 0.5
By Costa Mouratidis (costa@home.com)

Im sick and tired of all the lame shareware crap circulating around on the
net, with some lame 20 year old from sweden charging 40 dollars CDN for some
crappy util of which all the source code was obtained from newsgroups.
All this code is MINE and MINE only, and this program is totally open, in
that I am freely distributing the source code to this program, because that
is the only way that this program will every get better. People don't realise
that software gets alot better if everyone who has a chance to use it, is able
to add features that they would like to see, or change something that doesnt
work on a certain system, etc.
I welcome any comments, questions and feedback that anyone cane give me, but
I DO NOT want any complaints about how some 1000 dollar commercial products
is better, ITS FREE, so don't complain, I wrote this program to meet my needs
not anyones else's so if it helps you, fine, but if it doesn't, I DONT CARE.
Of course, don't let that comment scare you away from emailing me, I would
love to have people send me positive comments, new graphic filter algorithms
or anything they think would be useful, including ideas for new features and
things like that, and of course, if I use anyone's idea, they will get
appropriate credit. And with such in mind I would hope that if any substantial
part of my program is used in someone else's software, I would AT LEAST, just
like for you to send me an email saying thanx, and if you are considerate, my
name in the credits somewhere.
I didn't bother to comment my code because I don't need it, im sorry for that
but it's just too boring. It should be fairly easy to understand though.
Please experiment with my code, and try to add useful features (then send
them to me), and keep in mind, this was written in two days, so dont expect
wonders. The Version 1 will be (hopefully) a copied version of Photoshop 3,
with the ability to write your own plugins (easily), look for it soon.
Again, if you have any questions or comments, or additions, corrections,
whatever, please email me at costa@home.com.
Please don't email with general questions about the code though.
And no flames either, I know photoshop is better, but I'm trying to provide
and open alternative for people who don't want to pirate, and who don't have
money to burn.

Keep it free!

