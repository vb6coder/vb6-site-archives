SPECIAL NOTES ON THIS CUSTOM 'FLOATING' ODD WINDOW EXAMPLE
==========================================================

T'was hard doing this. Took me a few hours.

I got to know a few things from this and perhaps you'll too.

I hope you enjoy this control. perhaps we could get a bill gates
picture and use him as well. Huh!

Double-Click on the control and then drag him around.

Think of all the possibilities you could have, just by studying this
extraordinary code. You'll have a fun time looking at all the
special effects. Yeah!

Everybody have a good time and I hope you like this control.

Adapt to suit your own special needs.

B.T.W. It's been good knowing and will still be good knowing the
public.vb.* newsgroups.