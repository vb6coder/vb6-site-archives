Encrypt - Rudimentary encryption/decryption demo program
Copyright (c) 1997 SoftCircuits Programming (R)
Redistributed by Permission.

This Visual Basic 5.0 example program demonstrates a very simple
encryption/decryption algorithm. Although the algorithm is very
simple, it makes use of a password to provide a reasonable level of
security for non-critical applications.

Note: Under some circumstances, it may be possible for the encrypted
string to include Chr$(0). Visual Basic handles this just fine but
Windows (and therefore the TextBox control) uses Chr$(0) to signify
the end of the string. Therefore, programs such as this one that
store the encrypted data in a text box may end up truncating the
data. Proper use of this algorithm should involve storing the data
where all characters are supported such as to a binary file.

This program may be distributed on the condition that it is
distributed in full and unchanged, and that no fee is charged for
such distribution with the exception of reasonable shipping and media
charged. In addition, the code in this program may be incorporated
into your own programs and the resulting programs may be distributed
without payment of royalties.

This example program was provided by:
 SoftCircuits Programming
 http://www.softcircuits.com
 P.O. Box 16262
 Irvine, CA 92623
